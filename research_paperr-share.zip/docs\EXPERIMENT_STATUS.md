# Experiment status

| Experiment | Configuration | Command | Status | Output |
|---|---|---|---|---|
| Smoke | `configs/smoke.json` | `python -m iot_fl.experiment --config configs/smoke.json --output results/smoke` | Completed; 40 round records | `results/smoke/` |
| Standard synthetic multi-seed pilot | `configs/standard_suite.json` | `python -m iot_fl.suite --config configs/standard_suite.json --output results/standard` | Completed; 80 run directories, but 6 clients round 10/20/30% to one malicious client after integer conversion | `results/standard/` |
| Standard synthetic multi-seed corrected | `configs/standard_10_clients.json` | `python -m iot_fl.suite --config configs/standard_10_clients.json --output results/standard_10` | Completed; 80 run directories, five seeds per condition | `results/standard_10/` |
| ARS ablation | `configs/ablation.json` | `python -m iot_fl.suite --config configs/ablation.json --output results/ablation` | Completed; 20 run directories | `results/ablation/` |
| Adaptive attack | `configs/adaptive.json` | `python -m iot_fl.suite --config configs/adaptive.json --output results/adaptive` | Completed after correcting reference-order bug; 20 run directories | `results/adaptive/` |
| Scalability/dropout pilot | inline config in `iot_fl/scalability.py` | `python -m iot_fl.scalability --output results/scalability` | Completed; 6 configurations | `results/scalability/` |
| Statistical analysis | `results/standard_10/all_rounds.csv` | `python -m iot_fl.statistics --input results/standard_10/all_rounds.csv --output results/tables/standard_10_statistics.csv` | Completed; CIs and paired sign-flip tables | `results/tables/` |
| Latency/resource pilot | inline config in `iot_fl/resource.py` | `python -m iot_fl.resource --output results/resource` | Completed; 3 artificial latency levels | `results/resource/` |
| Real IoT dataset | N/A | N/A | Not evaluated; no local dataset available | `docs/REAL_DATASET_SETUP.md` |
| Krum baseline | `configs/krum.json` | `python -m iot_fl.suite --config configs/krum.json --output results/krum` | Completed; 30 run directories, five seeds; synthetic only | `results/krum/` |
| N-BaIoT archive validation | `data/nbaiot/manifest.json` | `python -c "from iot_fl.nbaiot import *; ..."` | Completed; nine benign CSVs, 555,932 rows; attack RARs not extracted | `data/nbaiot/manifest.json` |
| N-BaIoT real-data pilot | UCI N-BaIoT archive | Pending RAR backend | Blocked; no real classification/FL records processed | `docs/REAL_DATASET_RESULTS.md` |

The smoke run completed with 4 tests passing before the suite extension.
Standard-suite outputs must be read from raw per-run CSV files; a missing
directory is not interpreted as zero or as a failed experiment.
