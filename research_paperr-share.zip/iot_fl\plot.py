"""Plot only persisted experiment outputs."""
import sys
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

def main():
    root = Path(sys.argv[1]); df = pd.read_csv(root / "metrics.csv")
    for metric in ("accuracy", "f1", "flagged_clients"):
        ax = df.pivot(index="round", columns="method", values=metric).plot(marker="o", title=metric)
        ax.figure.tight_layout(); ax.figure.savefig(root / (metric + ".png")); plt.close(ax.figure)

if __name__ == "__main__": main()

