"""Run and summarize matched multi-seed synthetic experiment matrices."""
import argparse
import json
from pathlib import Path
import pandas as pd
from .experiment import run

def run_suite(config, root):
    root.mkdir(parents=True, exist_ok=True)
    raw_root = root / "raw"
    records = []
    seeds = config.get("seeds", [7, 17, 27, 37, 47])
    for seed in seeds:
        for fraction in config.get("attack_fractions", [0.0, .1, .2, .3]):
            for attack in config.get("attacks", ["sign_flip", "noise"]):
                for heterogeneity in config.get("heterogeneities", [0.0, .7]):
                    run_config = {k: v for k, v in config.items()
                                  if k not in {"seeds", "attack_fractions", "attacks", "heterogeneities"}}
                    run_config.update(seed=seed, attack_fraction=fraction,
                                      attack=attack, heterogeneity=heterogeneity)
                    name = f"seed-{seed}_frac-{fraction:.1f}_attack-{attack}_het-{heterogeneity:.1f}"
                    output = raw_root / name
                    if (output / "summary.json").exists():
                        status = json.loads((output / "summary.json").read_text()).get("status")
                        if status == "completed":
                            continue
                    rows, _ = run(run_config, output)
                    records.extend(rows)
    files = list(raw_root.glob("*/metrics.csv"))
    records = [row for file in files for row in pd.read_csv(file).to_dict("records")]
    raw = pd.DataFrame(records)
    raw.to_csv(root / "all_rounds.csv", index=False)
    final = raw.sort_values("round").groupby(
        ["seed", "attack_fraction", "attack", "heterogeneity", "method"], as_index=False
    ).tail(1)
    summary = final.groupby(
        ["attack_fraction", "attack", "heterogeneity", "method"], as_index=False
    ).agg(runs=("seed", "nunique"), accuracy_mean=("accuracy", "mean"),
          accuracy_std=("accuracy", "std"), f1_mean=("f1", "mean"),
          f1_std=("f1", "std"), detection_precision_mean=("detection_precision", "mean"),
          detection_recall_mean=("detection_recall", "mean"),
          benign_rejection_rate_mean=("benign_rejection_rate", "mean"),
          aggregation_seconds_mean=("aggregation_seconds", "mean"),
          communication_values=("communication_values", "mean"))
    summary.to_csv(root / "summary.csv", index=False)
    (root / "summary.json").write_text(json.dumps({
        "status": "completed", "synthetic": True, "seeds": seeds,
        "completed_run_directories": len(files), "statistic": "sample standard deviation"
    }, indent=2))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    run_suite(json.loads(Path(args.config).read_text()), Path(args.output))

if __name__ == "__main__":
    main()
