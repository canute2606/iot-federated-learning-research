from zipfile import ZipFile
import pandas as pd
from iot_fl.nbaiot import inspect_archive, profile_csv

def test_archive_inspection_and_csv_profile(tmp_path):
    csv = tmp_path / "device" / "benign_traffic.csv"
    csv.parent.mkdir()
    pd.DataFrame({"a": [1, 2], "b": [3, 4]}).to_csv(csv, index=False)
    archive = tmp_path / "sample.zip"
    with ZipFile(archive, "w") as z:
        z.write(csv, "device/benign_traffic.csv")
    info = inspect_archive(archive)
    assert info["benign_csv_entries"] == ["device/benign_traffic.csv"]
    profile = profile_csv(csv)
    assert profile["rows"] == 2 and profile["invalid_numeric_values"] == 0
