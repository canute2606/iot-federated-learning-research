"""N-BaIoT archive inspection, profiling, and bounded dataset loading."""
from pathlib import Path
from zipfile import ZipFile
import json
import numpy as np
import pandas as pd
from .real_data import RealDataset

EXPECTED_FEATURES = 115

def find_archive(root):
    archives = sorted(Path(root).glob("*.zip"))
    if not archives:
        raise FileNotFoundError(f"no N-BaIoT zip archive in {Path(root)}")
    if len(archives) > 1:
        raise ValueError(f"multiple archives found; choose explicitly: {archives}")
    return archives[0]

def inspect_archive(path):
    path = Path(path)
    with ZipFile(path) as archive:
        bad = archive.testzip()
        entries = [info for info in archive.infolist() if not info.is_dir()]
        return {
            "archive": str(path),
            "compressed_bytes": path.stat().st_size,
            "entries": len(entries),
            "uncompressed_bytes": sum(i.file_size for i in entries),
            "crc_error": bad,
            "benign_csv_entries": sorted(i.filename for i in entries
                                         if i.filename.lower().endswith("benign_traffic.csv")),
            "attack_rar_entries": sorted(i.filename for i in entries
                                         if i.filename.lower().endswith("_attacks.rar")),
        }

def profile_csv(path, chunksize=50_000):
    path = Path(path)
    columns = None
    rows = 0
    invalid = 0
    duplicate_rows_within_chunks = 0
    for chunk in pd.read_csv(path, chunksize=chunksize):
        columns = list(chunk.columns) if columns is None else columns
        rows += len(chunk)
        numeric = chunk.apply(pd.to_numeric, errors="coerce")
        invalid += int((~np.isfinite(numeric.to_numpy(dtype=float))).sum())
        duplicate_rows_within_chunks += int(chunk.duplicated().sum())
    if columns is None:
        raise ValueError(f"empty CSV: {path}")
    return {
        "file": str(path),
        "rows": rows,
        "columns": len(columns),
        "feature_names": columns,
        "invalid_numeric_values": invalid,
        "duplicate_rows_within_chunks": duplicate_rows_within_chunks,
        "label": "benign",
    }


def profile_tree(root, label):
    """Profile CSV files below a directory without loading them in full."""
    profiles = []
    for path in sorted(Path(root).rglob("*.csv")):
        profile = profile_csv(path)
        profile["label"] = label
        relative = path.relative_to(root)
        profile["relative_file"] = str(relative)
        profiles.append(profile)
    return profiles


def extract_attack_rars(archive_path, staging_root, seven_zip):
    """Extract RAR members from the ZIP, preserving their archive paths.

    RAR extraction itself is intentionally delegated to the caller's 7-Zip
    command; this function only stages the original RAR members safely.
    """
    staging_root = Path(staging_root)
    staging_root.mkdir(parents=True, exist_ok=True)
    staged = []
    with ZipFile(archive_path) as archive:
        for info in archive.infolist():
            if info.is_dir() or not info.filename.lower().endswith("_attacks.rar"):
                continue
            target = staging_root / info.filename
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info) as source, target.open("wb") as destination:
                while block := source.read(1024 * 1024):
                    destination.write(block)
            staged.append(target)
    return staged


def load_nbaiot(benign_root, attack_root, seed=0, max_rows_per_file=2000,
                test_fraction=.2, validation_fraction=.1,
                sampling_mode="full", split_mode="row"):
    """Load a reproducible bounded N-BaIoT sample with train-only scaling.

    Device directories define federated clients. Each source CSV is split
    independently, preventing identical source streams from crossing splits.
    """
    benign_root, attack_root = Path(benign_root), Path(attack_root)
    sources = [(path, 0, benign_root) for path in sorted(benign_root.rglob("*.csv"))]
    sources += [(path, 1, attack_root) for path in sorted(attack_root.rglob("*.csv"))]
    if not sources:
        raise FileNotFoundError("no N-BaIoT benign or attack CSV files found")
    rng = np.random.default_rng(seed)
    frames, labels, clients, splits = [], [], [], []
    feature_names = None
    client_names = {}
    source_splits = assign_source_groups(
        sources, seed, test_fraction, validation_fraction
    ) if split_mode == "source_group" else {}
    if split_mode not in {"row", "source_group"}:
        raise ValueError("split_mode must be 'row' or 'source_group'")
    source_groups = []
    for path, label, source_root in sources:
        if sampling_mode == "reservoir":
            frame = _reservoir_sample(path, max_rows_per_file, rng)
        elif sampling_mode == "full":
            frame = pd.read_csv(path)
            if len(frame) > max_rows_per_file:
                selected = np.sort(rng.choice(len(frame), max_rows_per_file, replace=False))
                frame = frame.iloc[selected]
        else:
            raise ValueError("sampling_mode must be 'full' or 'reservoir'")
        numeric = frame.apply(pd.to_numeric, errors="coerce")
        if feature_names is None:
            feature_names = tuple(numeric.columns)
        if tuple(numeric.columns) != feature_names:
            raise ValueError(f"feature schema mismatch in {path}")
        if numeric.isna().all(axis=None):
            raise ValueError(f"no numeric values in {path}")
        numeric = numeric.replace([np.inf, -np.inf], np.nan)
        numeric = numeric.fillna(0.0)
        device = path.relative_to(source_root).parts[0]
        group = source_group_key(path, source_root, label)
        if split_mode == "source_group":
            split = np.full(len(numeric), source_splits[group], dtype="<U5")
        else:
            order = rng.permutation(len(numeric))
            test_n = max(1, int(len(numeric) * test_fraction))
            val_n = max(1, int(len(numeric) * validation_fraction))
            split = np.full(len(numeric), "train", dtype="<U5")
            split[order[:test_n]] = "test"
            split[order[test_n:test_n + val_n]] = "val"
        client_names.setdefault(device, len(client_names))
        frames.append(numeric.to_numpy(float))
        labels.append(np.full(len(numeric), label, dtype=np.int64))
        clients.append(np.full(len(numeric), client_names[device], dtype=np.int64))
        splits.append(split)
        source_groups.append(np.full(len(numeric), group, dtype="<U260"))
    x = np.concatenate(frames)
    y = np.concatenate(labels)
    client = np.concatenate(clients)
    split = np.concatenate(splits)
    source_group = np.concatenate(source_groups)
    train = split == "train"
    mean = x[train].mean(axis=0)
    std = x[train].std(axis=0) + 1e-8
    data = RealDataset((x - mean) / std, y, client, split, feature_names,
                       source_group)
    if not np.isfinite(data.x).all():
        raise ValueError("N-BaIoT preprocessing produced non-finite values")
    return data, {value: key for key, value in client_names.items()}


def source_group_key(path, source_root, label):
    return f"{label}:{path.relative_to(source_root).as_posix()}"


def assign_source_groups(sources, seed, test_fraction, validation_fraction):
    """Assign complete source CSVs to disjoint train/val/test partitions."""
    rng = np.random.default_rng(seed)
    records = []
    for path, label, root in sources:
        relative = path.relative_to(root)
        group = source_group_key(path, root, label)
        device = relative.parts[0]
        records.append((group, device, label))
    assignments = {}
    benign = [record for record in records if record[2] == 0]
    if len(benign) < 3:
        raise ValueError("source-group split needs at least three benign files")
    benign_order = rng.permutation(len(benign))
    test_n = max(1, int(round(len(benign) * test_fraction)))
    val_n = max(1, int(round(len(benign) * validation_fraction)))
    for position, index in enumerate(benign_order):
        split = "test" if position < test_n else "val" if position < test_n + val_n else "train"
        assignments[benign[index][0]] = split
    by_device = {}
    for record in records:
        if record[2] == 1:
            by_device.setdefault(record[1], []).append(record)
    for device, groups in sorted(by_device.items()):
        if len(groups) < 3:
            raise ValueError(f"source-group split needs at least three attack files for {device}")
        order = rng.permutation(len(groups))
        test_n = max(1, int(round(len(groups) * test_fraction)))
        val_n = max(1, int(round(len(groups) * validation_fraction)))
        for position, index in enumerate(order):
            split = "test" if position < test_n else "val" if position < test_n + val_n else "train"
            assignments[groups[index][0]] = split
    return assignments


def _reservoir_sample(path, size, rng, chunksize=50_000):
    """Sample rows without replacement while bounding raw-file memory."""
    reservoir = []
    seen = 0
    for chunk in pd.read_csv(path, chunksize=chunksize):
        for row in chunk.itertuples(index=False, name=None):
            seen += 1
            if len(reservoir) < size:
                reservoir.append(row)
            else:
                slot = int(rng.integers(seen))
                if slot < size:
                    reservoir[slot] = row
    if not reservoir:
        raise ValueError(f"empty CSV: {path}")
    return pd.DataFrame.from_records(reservoir, columns=chunk.columns)

def extract_benign_csvs(archive_path, output_root):
    output_root = Path(output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    extracted = []
    with ZipFile(archive_path) as archive:
        for info in archive.infolist():
            if info.is_dir() or not info.filename.lower().endswith("benign_traffic.csv"):
                continue
            target = output_root / info.filename
            target.parent.mkdir(parents=True, exist_ok=True)
            if not target.exists() or target.stat().st_size != info.file_size:
                with archive.open(info) as source, target.open("wb") as destination:
                    while block := source.read(1024 * 1024):
                        destination.write(block)
            extracted.append(target)
    return extracted

def write_manifest(archive_path, extracted_root, output):
    archive_info = inspect_archive(archive_path)
    csvs = sorted(Path(extracted_root).glob("*/*.csv"))
    profiles = [profile_csv(path) for path in csvs]
    if profiles and any(p["columns"] != EXPECTED_FEATURES for p in profiles):
        raise ValueError("N-BaIoT benign files do not have the expected 115 features")
    manifest = {"archive": archive_info, "benign_profiles": profiles,
                "status": "benign-only validation; attack RAR files not extracted"}
    Path(output).write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest
