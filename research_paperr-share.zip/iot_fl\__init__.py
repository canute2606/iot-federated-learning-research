"""Reproducible IoT federated-learning poisoning study."""

__version__ = "0.1.0"

