# Statistical analysis

The standard suite uses five matched seeds: 7, 17, 27, 37, and 47. Summary
standard deviations are **sample standard deviations** (`ddof=1`) across the
final round of each completed seed/configuration. Per-round observations are
not treated as independent repetitions. The current analysis reports mean and
standard deviation only; confidence intervals, paired tests, and effect sizes
remain pending because they require a pre-registered comparison set and
additional review of metric distributions.

The auxiliary ablation and adaptive matrices also use five matched seeds and
sample standard deviations. The generated 95% intervals use a normal
approximation (`mean +/- 1.96 * standard error`) and are clipped to the valid
metric range; with only five seeds they are descriptive, not a guarantee of
normality. `iot_fl.statistics` also computes exact paired sign-flip
permutation p-values for final-round ARS-versus-baseline F1 on matched seeds.
These tests have small sample size, no multiple-comparison correction, and
should not be interpreted as definitive significance evidence. The scalability
pilot is a resource measurement pilot, not an inferential study.

The Krum pilot can be analyzed with the same independent-seed procedure:

```powershell
python -m iot_fl.statistics --input results\krum\all_rounds.csv --output results\tables\krum_statistics.csv
```

Reproduce:

```powershell
python -m iot_fl.statistics --input results\standard_10\all_rounds.csv --output results\tables\standard_10_statistics.csv
```
# Real-data comparison

The N-BaIoT comparison uses three independent matched seeds (7, 17, 27),
not training rounds, with one final-round observation per seed and method.
Means, sample standard deviations (`ddof=1`), and descriptive normal-approximation
95% confidence intervals are in `results/real_nbaiot/statistics.csv`.
Exact two-sided paired sign-flip tests compare each method with ARS on the
same seeds in `results/real_nbaiot/paired_sign_flip.csv`. Every p-value is
0.25 with three pairs, so these tests provide very weak evidence and are not
statistical significance claims. No multiplicity correction was applied.

## Corrected expanded real-data comparison

The corrected N-BaIoT comparison uses five independent matched seeds
(7, 17, 27, 37, 47), 250 sampled rows per source file, five rounds, and two
explicitly malicious clients out of nine (2/9 = 22.22%). Final-round records
are in `results/real_nbaiot_expanded/per_seed_final.csv`; the complete input
is `results/real_nbaiot_expanded/all_rounds.csv`.

Means, sample standard deviations, and descriptive normal-approximation 95%
intervals are in `results/real_nbaiot_expanded/statistics.csv`. Exact paired
sign-flip tests are in `results/real_nbaiot_expanded/paired_sign_flip.csv`.
The smallest exact p-value is 0.0625. These tests have only five pairs and no
multiplicity correction; they do not support statistical significance claims.

## Source-group holdout comparison

The source-group holdout uses the same five independent seeds and final-round
unit of analysis. Results are in
`results/real_nbaiot_group_holdout/statistics.csv`, with paired tests in
`results/real_nbaiot_group_holdout/paired_sign_flip.csv`. The smallest exact
p-value is 0.0625. Confidence intervals are descriptive normal-approximation
intervals; no multiplicity correction was applied.
