"""Generic leakage-safe CSV loader for a future public IoT dataset."""
from dataclasses import dataclass
from pathlib import Path
import numpy as np
import pandas as pd

@dataclass
class RealDataset:
    x: np.ndarray
    y: np.ndarray
    client: np.ndarray
    split: np.ndarray
    feature_names: tuple[str, ...]
    source_group: np.ndarray | None = None

def load_csv(path, label_column, client_column=None, seed=0, test_fraction=.2):
    """Load a labelled CSV; preprocessing statistics are fitted on train rows."""
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"dataset file not found: {path}")
    frame = pd.read_csv(path)
    if label_column not in frame:
        raise ValueError(f"missing label column: {label_column}")
    client = (frame[client_column].to_numpy() if client_column and client_column in frame
              else np.zeros(len(frame), dtype=int))
    labels = frame[label_column].astype("category")
    y = labels.cat.codes.to_numpy(dtype=np.int64)
    excluded = {label_column} | ({client_column} if client_column else set())
    features = [c for c in frame.columns if c not in excluded]
    numeric = frame[features].apply(pd.to_numeric, errors="coerce")
    if numeric.isna().all(axis=None):
        raise ValueError("no numeric feature values remain after conversion")
    numeric = numeric.fillna(numeric.median(numeric_only=True)).fillna(0)
    rng = np.random.default_rng(seed)
    order = rng.permutation(len(frame))
    test_n = max(1, int(len(frame) * test_fraction))
    split = np.full(len(frame), "train", dtype="<U5")
    split[order[:test_n]] = "test"
    train = split == "train"
    mean = numeric.loc[train].to_numpy(float).mean(axis=0)
    std = numeric.loc[train].to_numpy(float).std(axis=0) + 1e-8
    return RealDataset((numeric.to_numpy(float) - mean) / std, y, client, split,
                       tuple(features))

def check_integrity(data):
    if len(data.x) != len(data.y) or len(data.y) != len(data.split):
        raise ValueError("feature, label, and split lengths differ")
    if not np.isfinite(data.x).all():
        raise ValueError("preprocessed features contain non-finite values")
    if not {"train", "test"}.issubset(set(np.unique(data.split))):
        raise ValueError("loader must produce train and test partitions")
    return {"rows": len(data.y), "features": data.x.shape[1],
            "classes": int(len(np.unique(data.y))),
            "train_rows": int((data.split == "train").sum()),
            "test_rows": int((data.split == "test").sum())}
