# Ablation results

The five-seed ablation is complete in `results/ablation/`. Variants correspond
to actual ARS components: `ars_no_score` disables anomaly scoring,
`ars_no_clip` disables norm clipping, and `ars_mean_center` replaces the
robust median center with a mean center.

Across clean and poisoned IID/non-IID conditions, `ars_no_score` had zero
benign rejection but also zero malicious-client recall. The full ARS averaged
about 10.6% benign rejection and 50% detection recall in this small matrix.
These findings show a security/false-alarm trade-off; they do not establish
that full ARS is preferable.
