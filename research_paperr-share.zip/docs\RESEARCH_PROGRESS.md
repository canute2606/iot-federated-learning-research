# Research progress

## Completed and verified

- Existing smoke configuration and outputs preserved in `results/smoke/`.
- Synthetic data generator with train-only normalization and separate
  train/validation/test labels.
- FedAvg, FedAvgM, coordinate median, trimmed mean, and ARS implementations.
- Sign-flip, model-replacement, and noise update attacks.
- Per-round classification, communication, timing, and client-detection metrics.
- Five-seed suite configuration and resumable raw-run layout.
- Initial five-seed matrix completed: 80 run directories and saved raw records.
- Literature review, threat model, architecture, and draft manuscript.

## Partially completed

- Standard synthetic matrix is implemented and runnable; full matrix execution
  is reported in `docs/EXPERIMENT_STATUS.md` after execution.
- ARS is an engineering combination, not a verified novelty claim.

## Pending

- Adaptive attack implementation and evaluation.
- Explicit ablations and scalability matrix.
- Real IoT dataset acquisition, loader, and validation.
- Statistical tests beyond mean and sample standard deviation.
- Submission-ready paper and claim/evidence audit.
