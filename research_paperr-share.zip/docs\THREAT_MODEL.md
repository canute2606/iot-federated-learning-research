# Threat model and evaluation protocol

The server coordinates synchronous rounds and is trusted not to alter the
global model. A compromised client may control its local training loop and
submitted update, but cannot read another client's private records or modify
the held-out global test set. Attacks are untargeted update poisoning in this
version: sign flip, model replacement, and additive noise. Label poisoning and
backdoors are future experiments, not silently implied results.

For each round, the server receives one vector per participating client.
FedAvg and FedAvgM are vulnerable baselines. Coordinate median and trimmed mean
are established robust baselines. ARS computes a median-centered distance,
optionally adds disagreement with the previous aggregate, clips extreme
updates, and reports flagged clients. A high score is only a suspicion signal:
legitimate non-IID clients can be flagged, so benign rejection rate is recorded.

The test set is assigned at data generation and is never used for update
scoring. Communication volume is reported as the number of transmitted scalar
values; this is a simulation proxy, not a physical radio measurement.

