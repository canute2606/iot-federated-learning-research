"""Measured client-count/dropout scalability pilot."""
import argparse
import json
import time
from pathlib import Path
import pandas as pd
from .experiment import run

def run_scalability(root):
    root.mkdir(parents=True, exist_ok=True)
    rows = []
    for clients in (6, 10, 20):
        for dropout in (0.0, 0.2):
            config = {
                "clients": clients, "samples_per_client": 100, "features": 8,
                "rounds": 8, "local_epochs": 2, "learning_rate": .12,
                "methods": ["fedavg", "median", "ars"], "seed": 7,
                "attack_fraction": .2, "attack": "sign_flip",
                "heterogeneity": .7, "dropout": dropout,
            }
            output = root / f"clients-{clients}_dropout-{dropout:.1f}"
            if not (output / "summary.json").exists():
                started = time.perf_counter()
                run(config, output)
                wall = time.perf_counter() - started
                (output / "wall_clock.json").write_text(json.dumps({
                    "wall_clock_seconds": wall, "measured_on": "local Python process"
                }, indent=2))
            metrics = pd.read_csv(output / "metrics.csv")
            final = metrics.sort_values("round").groupby("method").tail(1)
            wall_data = json.loads((output / "wall_clock.json").read_text())
            for record in final.to_dict("records"):
                record.update(clients=clients, dropout=dropout,
                              wall_clock_seconds=wall_data["wall_clock_seconds"],
                              model_values=9, estimated_model_bytes=9 * 8)
                rows.append(record)
    pd.DataFrame(rows).to_csv(root / "scalability.csv", index=False)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    run_scalability(Path(args.output))

if __name__ == "__main__":
    main()
