# Real dataset results

## Dataset and extraction

The UCI N-BaIoT archive passed ZIP CRC validation. 7-Zip 26.05 tested all
16 staged RAR members successfully and extracted 80 attack CSVs under
`data/nbaiot/extracted_attacks/`. The original ZIP was not modified.

The extracted attack files contain 6,506,674 observed rows across nine
devices, 45 Gafgyt files, and 35 Mirai files. All attack and benign files have
the same 115 numeric feature columns. Chunked profiling found zero missing or
invalid/non-finite numeric values. These are integrity observations, not
model-evaluation results. Details are in `data/nbaiot/manifest.json`.

## Audit findings

The original three-seed comparison labelled a condition as 20% poisoning, but
the runner used `int(9 * 0.2)`, poisoning one client (11.1%). Those outputs
are preserved under `results/real_nbaiot/` as historical pilot results and
must not be reported as an exact 20% condition. The audit is documented in
`docs/REAL_DATA_AUDIT.md`.

The loader samples each source CSV deterministically and fits normalization
statistics only on training rows. However, row-wise splitting places rows from
the same source capture file in train, validation, and test, creating a
capture-level correlation/leakage risk. The expanded results therefore remain
pilot evidence, not a leakage-free deployment estimate.

## Source-group holdout validation

The source-group protocol treats each complete CSV path as an atomic group.
Benign files are assigned globally and attack files are assigned within each
device, so source groups are disjoint while all nine device clients remain
represented. The five-seed holdout runs used 61 train groups, 10 validation
groups, and 18 test groups. Every partition contained both classes. This is
unseen-source-file evaluation within seen devices, not unseen-device
generalization.

Pilot outputs are in
`results/real_nbaiot_group_holdout/pilot_clean/` and
`results/real_nbaiot_group_holdout/pilot_poisoning/`. The expanded comparison
uses 250 rows per source file, five rounds, and seeds 7, 17, 27, 37, and 47.
All source groups are disjoint in every run, and the disjointness flag is
persisted in `dataset_summary.json`.

Holdout outputs:

- `results/real_nbaiot_group_holdout/all_rounds.csv`
- `results/real_nbaiot_group_holdout/per_seed_final.csv`
- `results/real_nbaiot_group_holdout/per_seed_f1.csv`
- `results/real_nbaiot_group_holdout/per_class_metrics.csv`
- `results/real_nbaiot_group_holdout/statistics.csv`
- `results/real_nbaiot_group_holdout/paired_sign_flip.csv`

Final-round F1 means and sample standard deviations are:

| Condition | FedAvg | FedAvgM | Median | Trimmed mean | Krum | ARS |
|---|---:|---:|---:|---:|---:|---:|
| Source-group clean | 0.7819 +/- 0.0881 | 0.7852 +/- 0.0853 | 0.7374 +/- 0.1440 | 0.7413 +/- 0.1046 | 0.7959 +/- 0.0756 | 0.8328 +/- 0.1000 |
| Source-group 2/9 sign-flip | 0.7324 +/- 0.0833 | 0.7314 +/- 0.0841 | 0.8415 +/- 0.0549 | 0.7982 +/- 0.0522 | 0.9213 +/- 0.0336 | 0.8863 +/- 0.0431 |

The coordinate-median advantage from the row-wise expanded evaluation does
not persist under source-group holdout. ARS had the highest clean mean F1,
while Krum had the highest poisoned mean F1. These are descriptive results:
the seed-level variability is substantial, especially in clean holdout, and
the exact paired tests have only five pairs. The smallest holdout p-value
against ARS is 0.0625, with no multiplicity correction.

Holdout resource measurements are in
`results/real_nbaiot_group_holdout/resource/`:

- Clean: 421.54 seconds wall-clock and 112,068,131 peak traced Python bytes
- Two-client sign-flip: 331.16 seconds wall-clock and 111,830,983 peak traced
  Python bytes

These are traced Python allocation proxies, not resident memory or physical
network measurements.

## Corrected protocol

The corrected runs use nine device clients, explicit `malicious_clients`, and
the exact realized fraction in every metrics file. The poisoning condition uses
two malicious clients, or 2/9 = 22.22%, rather than calling this exactly 20%.
Clean and poisoning runs use matched seeds and the same loader settings.

The corrected pilot uses 100 rows per source file and reservoir sampling:

- `results/real_nbaiot_audit/pilot_clean/`
- `results/real_nbaiot_audit/pilot_poisoning/`

Both pilots use two rounds and all six methods. They completed with finite
metrics and correct malicious-client metadata.

## Expanded comparison

The expanded comparison uses 250 rows per source file, five rounds, one local
epoch, and five independent matched seeds (7, 17, 27, 37, 47). It includes
FedAvg, FedAvgM, coordinate median, trimmed mean, Krum (`f=1`), and ARS.

Outputs:

- Per-run directories: `results/real_nbaiot_expanded/clean_*` and
  `results/real_nbaiot_expanded/poisoning_*`
- Per-seed final rows:
  `results/real_nbaiot_expanded/per_seed_final.csv`
- Compact per-seed F1 table:
  `results/real_nbaiot_expanded/per_seed_f1.csv`
- All rounds:
  `results/real_nbaiot_expanded/all_rounds.csv`
- Confidence intervals:
  `results/real_nbaiot_expanded/statistics.csv`
- Paired tests:
  `results/real_nbaiot_expanded/paired_sign_flip.csv`

Final-round F1 means and sample standard deviations are:

| Condition | FedAvg | FedAvgM | Median | Trimmed mean | Krum | ARS |
|---|---:|---:|---:|---:|---:|---:|
| Clean | 0.8074 +/- 0.0022 | 0.8117 +/- 0.0020 | 0.7763 +/- 0.0049 | 0.8041 +/- 0.0027 | 0.7800 +/- 0.0076 | 0.7839 +/- 0.0107 |
| 2/9 sign-flip | 0.7144 +/- 0.0148 | 0.7136 +/- 0.0148 | 0.9371 +/- 0.0055 | 0.8201 +/- 0.0030 | 0.8750 +/- 0.0752 | 0.8156 +/- 0.0040 |

Under the corrected poisoning condition, coordinate median had the highest
mean F1, followed by Krum. FedAvg and FedAvgM degraded substantially. ARS did
not have the best F1 and is not supported as superior or poisoning-resilient.
The large Krum standard deviation indicates unstable behavior across these
five seeds.

The earlier unexpected increase in poisoned F1 was caused by the mislabeled
one-client condition and a short-run decision-boundary effect. In the
corrected two-client experiment, FedAvg and FedAvgM decrease as expected,
while robust methods respond differently. This does not prove that poisoning
always lowers performance or that any method is universally robust.

## Statistical analysis

The expanded analysis treats five independent seeds as repetitions, not
individual records or rounds. It reports sample standard deviations and
descriptive normal-approximation 95% intervals. Exact paired sign-flip tests
compare each baseline with ARS on matched seeds. The smallest exact p-values
are 0.0625; no multiplicity correction was applied, and no statistical
significance claim is made.

## Resource profiling

The corrected real-data resource run is in
`results/real_nbaiot_audit/resource_corrected/`. It measures the complete
loader plus six-method pilot using `tracemalloc`:

- Clean: 353.62 seconds wall-clock; 102,998,315 peak traced Python bytes
- Two-client sign-flip: 312.31 seconds wall-clock; 102,747,763 peak traced
  Python bytes

These are process-level Python allocation proxies for this run, not resident
set size and not physical IoT or network measurements. Per-round local
training and aggregation times remain in each `metrics.csv`.

## Reproduction

```powershell
python -m iot_fl.experiment --config configs\nbaiot_corrected_pilot_clean.json --output results\real_nbaiot_audit\pilot_clean
python -m iot_fl.experiment --config configs\nbaiot_corrected_pilot_poisoning.json --output results\real_nbaiot_audit\pilot_poisoning
python -m iot_fl.statistics --input results\real_nbaiot_expanded\all_rounds.csv --output results\real_nbaiot_expanded\statistics.csv
```

The expanded runs use
`configs\nbaiot_expanded_clean.json` and
`configs\nbaiot_expanded_poisoning.json`, varying the seed across
7, 17, 27, 37, and 47. Existing synthetic and historical real-data outputs
remain preserved.

The source-group comparison uses
`configs\nbaiot_group_holdout_clean.json` and
`configs\nbaiot_group_holdout_poisoning.json`, varying the seed over 7, 17,
27, 37, and 47.
