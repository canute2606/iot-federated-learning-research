# Adaptive attack evaluation

The five-seed adaptive matrix is complete in `results/adaptive/`. The
`adaptive_evasion` attacker is a grey-box simulation: it observes the benign
reference direction available to the server-side scoring procedure and submits
a mostly aligned update with a small local-update component. It has no access
to held-out test records.

ARS detection recall was zero in the adaptive-evasion summary while benign
rejection remained approximately 7.5–15% across heterogeneity settings. The
adaptive attack therefore evaded the current ARS flagging rule in this
simulation. This is a negative finding, not evidence of adaptive resilience.
