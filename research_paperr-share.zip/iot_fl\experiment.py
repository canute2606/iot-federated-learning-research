"""Reproducible federated experiment runner."""
import argparse, json, time
from pathlib import Path
import numpy as np
from .data import make_dataset, client_partitions
from .nbaiot import load_nbaiot
from .model import train, predict
from .aggregation import fedavg, coordinate_median, trimmed_mean, krum, ars
from .attacks import poison
from .metrics import classification

def _malicious_count(config):
    if "malicious_clients" in config:
        count = int(config["malicious_clients"])
    else:
        count = int(config["clients"] * config.get("attack_fraction", 0))
    if count < 0 or count > config["clients"]:
        raise ValueError("malicious_clients must be between zero and client count")
    return count

def run(config, output):
    output.mkdir(parents=True, exist_ok=True)
    if config.get("dataset") == "nbaiot":
        data, client_names = load_nbaiot(
            config["benign_root"], config["attack_root"], seed=config["seed"],
            max_rows_per_file=config.get("max_rows_per_file", 2000),
            test_fraction=config.get("test_fraction", .2),
            validation_fraction=config.get("validation_fraction", .1),
            sampling_mode=config.get("sampling_mode", "full"),
            split_mode=config.get("split_mode", "row"),
        )
        config = dict(config)
        config["clients"] = len(client_names)
        config["features"] = data.x.shape[1]
    else:
        data = make_dataset(config["clients"], config["samples_per_client"], config.get("attack_prevalence", .25),
                            config.get("heterogeneity", .7), config["seed"])
    (output / "config.json").write_text(json.dumps(config, indent=2))
    partitions = client_partitions(data)
    malicious_count = _malicious_count(config)
    dataset_summary = {
        "dataset": config.get("dataset", "synthetic"),
        "rows": int(len(data.y)),
        "features": int(data.x.shape[1]),
        "clients": int(config["clients"]),
        "client_names": client_names if config.get("dataset") == "nbaiot" else {},
        "class_counts": {str(int(label)): int((data.y == label).sum())
                         for label in np.unique(data.y)},
        "client_class_counts": {
            str(int(cid)): {
                "rows": int((data.client == cid).sum()),
                "benign": int(((data.client == cid) & (data.y == 0)).sum()),
                "attack": int(((data.client == cid) & (data.y == 1)).sum()),
            } for cid in np.unique(data.client)
        },
        "split_counts": {split: int((data.split == split).sum())
                         for split in np.unique(data.split)},
        "split_class_counts": {
            split: {str(int(label)): int(((data.split == split) &
                                          (data.y == label)).sum())
                    for label in np.unique(data.y)}
            for split in np.unique(data.split)
        },
    }
    if data.source_group is not None:
        dataset_summary["source_groups"] = {
            split: sorted(set(data.source_group[data.split == split]))
            for split in np.unique(data.split)
        }
        dataset_summary["source_group_disjoint"] = len(set(
            data.source_group[data.split == "train"])) + len(set(
            data.source_group[data.split == "val"])) + len(set(
            data.source_group[data.split == "test"])) == len(set(data.source_group))
    (output / "dataset_summary.json").write_text(
        json.dumps(dataset_summary, indent=2))
    methods = config["methods"]; rows = []; events = []
    for method in methods:
        rng = np.random.default_rng(config["seed"])
        model = np.zeros(config["features"] + 1); momentum = np.zeros_like(model); previous = None
        for rnd in range(config["rounds"]):
            started = time.perf_counter()
            local_training_seconds = 0.0
            event_start = len(events)
            updates, sizes, ids = [], [], []
            malicious_ids = set()
            for cid, idx in partitions.items():
                if rng.random() < config.get("dropout", 0): continue
                train_started = time.perf_counter()
                local = train(model, data.x[idx], data.y[idx], config["local_epochs"], config["learning_rate"])
                local_training_seconds += time.perf_counter() - train_started
                update = local - model
                malicious = cid < malicious_count
                if malicious:
                    malicious_ids.add(cid)
                    attack = config.get("attack", "sign_flip")
                    if attack != "adaptive_evasion":
                        update = poison(update, model, attack, rng=rng)
                updates.append(update); sizes.append(len(idx)); ids.append(cid)
                events.append({"method": method, "round": rnd, "client": cid, "malicious": malicious})
                latency_ms = config.get("latency_ms", 0)
                if latency_ms:
                    time.sleep(latency_ms / 1000)
            if not updates: continue
            updates = np.asarray(updates)
            if config.get("attack") == "adaptive_evasion" and malicious_ids:
                benign_updates = [u for u, cid in zip(updates, ids) if cid not in malicious_ids]
                if benign_updates:
                    reference = np.median(benign_updates, axis=0)
                    for i, cid in enumerate(ids):
                        if cid in malicious_ids:
                            updates[i] = poison(updates[i], model, "adaptive_evasion",
                                                 reference=reference, rng=rng)
            aggregation_started = time.perf_counter()
            if method == "fedavg": result = fedavg(updates, sizes)
            elif method == "fedavgm":
                result = fedavg(updates, sizes); momentum = .9 * momentum + result.update; result.update = momentum
            elif method == "median": result = coordinate_median(updates)
            elif method == "trimmed_mean": result = trimmed_mean(updates)
            elif method == "krum":
                result = krum(updates, config.get("krum_byzantine_clients", 1))
            elif method == "ars": result = ars(updates, previous)
            elif method == "ars_no_score": result = ars(updates, previous, use_score=False)
            elif method == "ars_no_clip": result = ars(updates, previous, use_clip=False)
            elif method == "ars_mean_center": result = ars(updates, previous, use_robust=False)
            else: raise ValueError("unknown method: " + method)
            previous = result.update; model += result.update
            for offset, flagged in enumerate(result.flagged):
                events[event_start + offset]["flagged"] = bool(flagged)
            test = data.split == "test"; pred = predict(model, data.x[test])
            malicious_ids = {cid for cid in ids if cid < malicious_count}
            detected_ids = {cid for cid, flagged in zip(ids, result.flagged) if flagged}
            true_positive = len(malicious_ids & detected_ids)
            row = {"method": method, "round": rnd, "seed": config["seed"],
                   "attack_fraction": config.get("attack_fraction", 0),
                   "realized_attack_fraction": malicious_count / config["clients"],
                   "attack": config.get("attack", "none"),
                   "heterogeneity": config.get("heterogeneity", 0.7),
                   "aggregation_seconds": time.perf_counter() - aggregation_started,
                   "round_seconds": time.perf_counter() - started}
            row["local_training_seconds"] = local_training_seconds
            row["latency_ms"] = config.get("latency_ms", 0)
            row.update(classification(data.y[test], pred))
            row["flagged_clients"] = int(result.flagged.sum()); row["communication_values"] = int(len(updates) * len(model))
            row["malicious_clients"] = len(malicious_ids)
            row["detection_precision"] = true_positive / max(1, len(detected_ids))
            row["detection_recall"] = true_positive / max(1, len(malicious_ids))
            row["benign_rejection_rate"] = (len(detected_ids - malicious_ids) /
                                            max(1, len(set(ids) - malicious_ids)))
            rows.append(row)
    import pandas as pd
    pd.DataFrame(rows).to_csv(output / "metrics.csv", index=False)
    pd.DataFrame(events).to_csv(output / "client_events.csv", index=False)
    (output / "summary.json").write_text(json.dumps({
        "status": "completed", "synthetic": config.get("dataset") != "nbaiot",
        "dataset": config.get("dataset", "synthetic"), "rows": len(rows)
    }, indent=2))
    return rows, events

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True); parser.add_argument("--output", required=True)
    args = parser.parse_args()
    run(json.loads(Path(args.config).read_text()), Path(args.output))

if __name__ == "__main__": main()
