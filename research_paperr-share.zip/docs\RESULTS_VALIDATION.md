# Results validation

Validated on 2026-10-25:

- `results/standard_10/raw/` contains 80 unique run directories, all marked
  completed.
- There are five seeds: 7, 17, 27, 37, and 47.
- Each run has 5 methods × 8 rounds = 40 metric rows; the matrix contains
  3,200 rows and 400 final-round rows.
- Summary contains 80 rows: 4 attack fractions × 2 attack types × 2
  heterogeneity levels × 5 methods. Every summary row reports five seeds.
- Malicious-client mapping is exact: 0.0→0, 0.1→1, 0.2→2, 0.3→3 for ten
  clients.
- Smoke outputs are separate under `results/smoke/`.
- Raw configurations are persisted in every run directory.
- Aggregate standard deviations use sample `ddof=1`; rounds are not treated as
  independent repetitions.

The 6-client pilot in `results/standard/` is retained but not used for the
corrected comparison because 20% and 30% both map to one client.

No real dataset was found or evaluated. Auxiliary adaptive, ablation, and
scalability outputs are kept separate from the main matrix. The first adaptive
execution failed because the attack was applied before its reference update
existed; the corrected execution completed and the failed attempt was not
treated as data.
