# Final project status

This is not a submission-ready paper. The implementation and synthetic
standard matrix are verified, but several requested experiment families remain
pending.

## Completed

- Tests: 9 passed after the audit-driven runner and loader changes; corrected
  real-data pilots and expanded runs completed with finite persisted metrics.
- Smoke run: completed in `results/smoke/`.
- Corrected standard synthetic matrix: 80 run directories, five seeds,
  10 clients, 2 attack types, 4 malicious fractions, and 2 heterogeneity
  levels in `results/standard_10/`.
- Raw per-run metrics, aggregate means, sample standard deviations, timing, and
  communication counts are saved.
- ARS ablation: 20 run directories in `results/ablation/`.
- Adaptive attack: 20 run directories in `results/adaptive/`.
- Scalability pilot: 6 configurations in `results/scalability/`.
- Resource pilot: artificial latency and traced Python peak allocation in
  `results/resource/`.
- Confidence intervals and exact paired sign-flip analyses in
  `results/tables/standard_10_statistics.csv` and
  `results/tables/paired_sign_flip.csv`.
- N-BaIoT archive: ZIP CRC passed, all 16 RAR members passed 7-Zip testing,
  and 80 attack CSVs were extracted and profiled. Attack and benign files have
  115 consistent numeric columns and zero profiled invalid/non-finite values.
- Real-data loader and pilot: bounded device-aware N-BaIoT loading, train-only
  scaling, and train/validation/test separation are implemented and validated.
- Historical real-data comparison: three seeds, clean and a mislabeled
  one-client sign-flip condition, six methods, and three rounds are preserved
  under `results/real_nbaiot/`.
- Real-data audit: the prior condition labelled 20% was confirmed to poison
  one of nine clients (11.1%) because of floor rounding. The audit and
  correction plan are in `docs/REAL_DATA_AUDIT.md`.
- Corrected real-data pilots use reservoir sampling and write under
  `results/real_nbaiot_audit/`.
- Expanded corrected real-data comparison: five seeds, 250 rows per source
  file, five rounds, clean and two-of-nine sign-flip conditions, with all six
  methods under `results/real_nbaiot_expanded/`.
- Corrected real-data resource measurement is under
  `results/real_nbaiot_audit/resource_corrected/`.
- Source-group holdout validation: five seeds, 250 rows per source file,
  disjoint complete CSV groups, clean and two-client sign-flip conditions,
  and six methods are under `results/real_nbaiot_group_holdout/`.
- Krum baseline: 30 run directories in `results/krum/`, with the
  `n > 2f + 2` assumption enforced and `f=3` for ten clients.
- Krum confidence intervals and paired-analysis input are in
  `results/tables/krum_statistics.csv` and
  `results/tables/krum_paired_sign_flip.csv`.

## Measured findings

At 20% malicious clients, the corrected matrix's across-condition averages
showed robust methods retained approximately 0.998 accuracy while FedAvg and
FedAvgM were approximately 0.949. At 30%, median and ARS were approximately
0.998, while FedAvg/FedAvgM were approximately 0.448 and 0.449. These are
synthetic results from the saved summary and are not real-device validation.
The result varies by attack and heterogeneity; inspect the CSV before making
method-level claims. ARS also flagged benign clients in clean non-IID settings
(about 14–16% in the aggregate summary), so its current detection behavior is
not acceptable as a calibrated client-identification claim.

The separate Krum pilot was run with 120 samples per client and sign-flip
attacks. Its mean accuracy across heterogeneity levels was approximately
0.997 at 20% and 0.997 at 30%; these values are from `results/krum/summary.csv`
and are not directly interchangeable with the 160-sample standard matrix.

The corrected expanded N-BaIoT comparison found clean mean F1 of 0.8074
FedAvg, 0.8117 FedAvgM, 0.7763 median, 0.8041 trimmed mean, 0.7800 Krum,
and 0.7839 ARS. Under two malicious clients out of nine, means were 0.7144,
0.7136, 0.9371, 0.8201, 0.8750, and 0.8156, respectively. Coordinate median
was best in this tested poisoning condition; ARS was not superior.

The source-group holdout changed the ranking: clean mean F1 was highest for
ARS (0.8328), while two-client sign-flip mean F1 was highest for Krum
(0.9213), followed by ARS (0.8863). Coordinate median's row-wise advantage
did not persist. These results are unseen-source-file tests within seen
devices, not unseen-device generalization.

## Pending

N-BaIoT archive validation is complete: ZIP CRC passed, all 16 RAR members
passed 7-Zip testing, and 80 attack CSVs were profiled with 115 consistent
numeric columns. Real-data evaluation remains bounded: source files are
sampled, the row-wise protocol retains capture-level leakage risk while the
new holdout mitigates that risk for held-out groups, the sample is
imbalanced, and no full-archive federated run was completed. The resource
measurement is descriptive and uses traced Python allocation, not resident
memory or a physical benchmark. Final claim tracing is documented in
`paper/CLAIM_EVIDENCE_MATRIX.md`.

The paper remains a draft, not submission-ready. The real-data comparison does
not establish ARS superiority, poisoning resilience, or statistical
significance.

## Reproduction

```powershell
python -m pytest
python -m iot_fl.suite --config configs\standard_10_clients.json --output results\standard_10
python -m iot_fl.report results\standard_10
python -m iot_fl.statistics --input results\standard_10\all_rounds.csv --output results\tables\standard_10_statistics.csv
python -m iot_fl.resource --output results\resource
python -m iot_fl.suite --config configs\krum.json --output results\krum
python -m iot_fl.statistics --input results\krum\all_rounds.csv --output results\tables\krum_statistics.csv
python -m iot_fl.experiment --config configs\nbaiot_corrected_pilot_clean.json --output results\real_nbaiot_audit\pilot_clean
python -m iot_fl.experiment --config configs\nbaiot_corrected_pilot_poisoning.json --output results\real_nbaiot_audit\pilot_poisoning
python -m iot_fl.statistics --input results\real_nbaiot_expanded\all_rounds.csv --output results\real_nbaiot_expanded\statistics.csv
python -m iot_fl.experiment --config configs\nbaiot_group_holdout_pilot_clean.json --output results\real_nbaiot_group_holdout\pilot_clean
python -m iot_fl.experiment --config configs\nbaiot_group_holdout_pilot_poisoning.json --output results\real_nbaiot_group_holdout\pilot_poisoning
python -m iot_fl.statistics --input results\real_nbaiot_group_holdout\all_rounds.csv --output results\real_nbaiot_group_holdout\statistics.csv
```

The expanded configs are `configs\nbaiot_expanded_clean.json` and
`configs\nbaiot_expanded_poisoning.json`; vary the seed over 7, 17, 27, 37,
and 47. The paper remains a draft, not submission-ready.
