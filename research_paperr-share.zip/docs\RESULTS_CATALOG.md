# Results catalog

| Artifact | Source | Status |
|---|---|---|
| Smoke metrics | `results/smoke/metrics.csv` | Completed |
| Smoke plots | `results/smoke/*.png` | Completed |
| Multi-seed raw records | `results/standard/raw/*/metrics.csv` | Pending |
| Multi-seed summary | `results/standard/summary.csv` | Pending |
| Corrected multi-seed raw records | `results/standard_10/raw/*/metrics.csv` | Completed; 80 directories |
| Corrected multi-seed summary | `results/standard_10/summary.csv` | Completed |
| Corrected comparison tables | `results/standard_10/tables/` | Completed |
| Corrected comparison figures | `results/standard_10/figures/` | Completed |
| ARS ablation raw records | `results/ablation/` | Completed; 20 run directories |
| Adaptive attack raw records | `results/adaptive/` | Completed; 20 run directories |
| Scalability pilot | `results/scalability/` | Completed; 6 configurations |
| Statistical intervals and paired tests | `results/tables/standard_10_statistics.csv`, `results/tables/paired_sign_flip.csv` | Completed; descriptive five-seed analyses |
| Artificial-latency/resource pilot | `results/resource/resource.csv` | Completed; one-seed software pilot |
| Real IoT dataset | None | Not evaluated; setup documented |
| Krum baseline | `results/krum/` | Completed; 30 run directories with five seeds |
| Krum statistics | `results/tables/krum_statistics.csv` | Completed; descriptive five-seed intervals |

All summaries must be generated from raw CSV files and must retain the sample
standard deviation convention stated in `results/standard/summary.json`.
