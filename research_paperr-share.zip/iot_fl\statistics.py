"""Statistics over independent completed seeds, never over training rounds."""
import argparse
import math
from pathlib import Path
import numpy as np
import pandas as pd

def _ci95(values):
    values = np.asarray(values, dtype=float)
    mean = values.mean()
    se = values.std(ddof=1) / math.sqrt(len(values)) if len(values) > 1 else float("nan")
    return mean, mean - 1.96 * se, mean + 1.96 * se

def paired_sign_flip(a, b):
    """Exact two-sided paired sign-flip permutation p-value for small matched sets."""
    differences = np.asarray(a, dtype=float) - np.asarray(b, dtype=float)
    if len(differences) == 0:
        return float("nan")
    observed = abs(differences.mean())
    totals = []
    for mask in range(1 << len(differences)):
        signs = np.array([1 if mask & (1 << i) else -1 for i in range(len(differences))])
        totals.append(abs((differences * signs).mean()))
    return (sum(value >= observed - 1e-15 for value in totals) / len(totals))

def analyze(path, output):
    raw = pd.read_csv(path)
    final = raw.sort_values("round").groupby(
        ["seed", "attack_fraction", "attack", "heterogeneity", "method"], as_index=False
    ).tail(1)
    group_cols = ["attack_fraction", "attack", "heterogeneity", "method"]
    rows = []
    for keys, group in final.groupby(group_cols):
        values = group["f1"].to_numpy()
        mean, low, high = _ci95(values)
        rows.append(dict(zip(group_cols, keys), runs=len(values), f1_mean=mean,
                            f1_std=values.std(ddof=1) if len(values) > 1 else np.nan,
                            ci95_low=max(0.0, low), ci95_high=min(1.0, high)))
    summary = pd.DataFrame(rows)
    output = Path(output); output.parent.mkdir(parents=True, exist_ok=True)
    summary.to_csv(output, index=False)
    paired = []
    for keys, group in final.groupby(["attack_fraction", "attack", "heterogeneity"]):
        wide = group.pivot(index="seed", columns="method", values="f1").dropna()
        if "ars" not in wide:
            continue
        for method in wide.columns:
            if method != "ars":
                paired.append(dict(zip(["attack_fraction", "attack", "heterogeneity"], keys),
                                   method=method, comparison="ars", seeds=len(wide),
                                   p_value=paired_sign_flip(wide["ars"], wide[method])))
    pd.DataFrame(paired).to_csv(output.with_name("paired_sign_flip.csv"), index=False)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True); parser.add_argument("--output", required=True)
    args = parser.parse_args(); analyze(args.input, args.output)

if __name__ == "__main__":
    main()
