"""Explicit update-poisoning strategies used by the simulator."""
import numpy as np

def poison(update, global_model, strategy, strength=3.0, reference=None, rng=None):
    if strategy == "sign_flip":
        return -strength * update
    if strategy == "model_replacement":
        return strength * (np.sign(update) * (np.linalg.norm(global_model) + 1e-8))
    if strategy == "noise":
        return update + (rng or np.random.default_rng()).normal(0, strength, update.shape)
    if strategy == "adaptive_evasion":
        if reference is None:
            raise ValueError("adaptive_evasion requires a reference update")
        reference_norm = np.linalg.norm(reference) + 1e-8
        return .9 * reference + .1 * update * reference_norm / (np.linalg.norm(update) + 1e-8)
    raise ValueError("unknown attack strategy: " + strategy)
