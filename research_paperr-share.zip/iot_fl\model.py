"""Small NumPy logistic model suitable for constrained-client simulation."""
import numpy as np

def sigmoid(z):
    return 1 / (1 + np.exp(-np.clip(z, -40, 40)))

def predict(params, x):
    return (sigmoid(x @ params[:-1] + params[-1]) >= .5).astype(int)

def loss_grad(params, x, y):
    p = sigmoid(x @ params[:-1] + params[-1])
    err = p - y
    return np.r_[x.T @ err / len(y), err.mean()]

def train(params, x, y, epochs=1, lr=.1):
    out = params.copy()
    for _ in range(epochs):
        out -= lr * loss_grad(out, x, y)
    return out

