# Scalability and resource results

The client-count/dropout pilot is complete in `results/scalability/` for 6, 10,
and 20 clients with 0% and 20% simulated dropout. Wall-clock time is measured
for the local Python process, and communication values are scalar-count
estimates from the transmitted model vectors. No physical hardware or peak
memory benchmark is claimed. The pilot's aggregate wall times ranged from
about 0.0115 to 0.0260 seconds per configuration; dropout reduces transmitted
values but is not an accuracy improvement guarantee.
