"""Dedicated artificial-latency and peak-Python-memory pilot."""
import argparse
import json
import time
import tracemalloc
from pathlib import Path
import pandas as pd
from .experiment import run

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    root = Path(args.output); root.mkdir(parents=True, exist_ok=True)
    records = []
    for latency_ms in (0, 2, 10):
        config = {"clients": 10, "samples_per_client": 100, "features": 8,
                  "rounds": 4, "local_epochs": 2, "learning_rate": .12,
                  "methods": ["fedavg", "ars"], "seed": 7,
                  "attack_fraction": .2, "attack": "sign_flip",
                  "heterogeneity": .7, "dropout": 0.0,
                  "latency_ms": latency_ms}
        output = root / f"latency-{latency_ms}ms"
        tracemalloc.start(); started = time.perf_counter()
        run(config, output)
        wall = time.perf_counter() - started
        _, peak = tracemalloc.get_traced_memory(); tracemalloc.stop()
        final = pd.read_csv(output / "metrics.csv").sort_values("round").groupby("method").tail(1)
        for record in final.to_dict("records"):
            record.update(latency_ms=latency_ms, wall_clock_seconds=wall,
                          peak_python_bytes=peak)
            records.append(record)
        (output / "resource.json").write_text(json.dumps(
            {"latency_ms": latency_ms, "wall_clock_seconds": wall,
             "peak_python_bytes": peak}, indent=2))
    pd.DataFrame(records).to_csv(root / "resource.csv", index=False)

if __name__ == "__main__":
    main()
