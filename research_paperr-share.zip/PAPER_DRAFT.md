# A Lightweight and Poisoning-Resilient Federated Learning Framework for IoT Intrusion Detection Under Heterogeneous Data and Resource Constraints

**Status:** Research draft. Results include reproducible synthetic simulations
and a bounded N-BaIoT pilot/comparison; no physical device was evaluated and
the real-data study is not full-dataset validation.

## Abstract

Federated learning can retain IoT traffic locally while coordinating an
intrusion detector, but arbitrary client updates and heterogeneous traffic can
degrade aggregation. This work presents a reproducible NumPy simulation that
generates labelled synthetic IoT traffic, partitions it across ten virtual
clients, and compares FedAvg, FedAvgM, coordinate-wise median, trimmed mean,
and an explicitly non-novel engineering defense called Adaptive Robust Score
(ARS). ARS combines median-centered scoring, temporal similarity, and bounded
updates. Across five matched seeds, static sign-flip and noise experiments
showed that robust aggregators retained high synthetic test performance while
FedAvg and FedAvgM degraded at higher malicious-client fractions. However, ARS
rejected benign clients under clean non-IID traffic and failed to detect the
tested grey-box adaptive-evasion attack. These negative findings prevent a
claim of general poisoning resilience or client-identification reliability.
Artificial-latency and traced-Python-memory pilots quantify software overhead
only. A bounded N-BaIoT comparison was completed with five seeds and five
rounds; it does not establish source-level generalization or universal
robustness.

**Keywords:** federated learning, IoT intrusion detection, model poisoning,
non-IID data, Byzantine robustness, reproducibility

## 1. Introduction

IoT deployments produce distributed network observations across devices with
different traffic profiles. Federated learning (FL) offers a way to train a
shared detector without centralizing raw records, but the server must aggregate
client updates that may be statistically different or maliciously crafted.
This project asks: (1) how do common aggregators behave under static update
poisoning, (2) does heterogeneity cause a lightweight anomaly score to reject
legitimate clients, and (3) what software overhead accompanies robust
aggregation?

The contribution is a transparent, reproducible evaluation protocol and
implementation, not a verified claim that ARS is novel or superior. Every
completed numerical result is linked to a saved CSV in
`paper/CLAIM_EVIDENCE_MATRIX.md`.

## 2. Related work and research gap

PEIoT-DS motivates privacy-preserving FL for IoT intrusion detection
(Khraisat et al., 2025). FedAvg is the standard weighted aggregation baseline
(McMahan et al., 2017). Krum introduced Byzantine-resilient distance-based
selection (Blanchard et al., 2017), while coordinate median and trimmed mean
provide robust statistical alternatives (Yin et al., 2018). FedREDefense uses
model-update reconstruction error for poisoning defense under non-IID
conditions (Xie et al., 2024).

ARS is intentionally described as an engineering combination of known ideas.
The defensible gap addressed here is a reproducible small-device-oriented
comparison of static poisoning, non-IID shifts, false rejection, adaptive
evasion, and software resource proxies. A systematic novelty study and
real-world validation are not complete.

## 3. Threat model

The server is assumed to coordinate synchronous rounds and preserve the held-
out test set. A compromised client can control its local update and submit an
arbitrary vector, but cannot read other clients' raw records or modify the
test set. Evaluated attacks are sign flip, additive noise, model replacement in
the implementation, and a grey-box adaptive-evasion update. Label poisoning,
backdoors, secure aggregation, and privacy attacks are outside this study.

## 4. Proposed method

Let client update vectors be \(u_i\), and let \(c\) be their coordinate-wise
median. ARS computes robust distances
\[
d_i = ||u_i-c||_2
\]
and a robust standardized score using the median and median absolute
deviation. After the first round, it adds a penalty for disagreement with the
previous aggregate direction. Updates above the configured score threshold are
flagged. The retained updates are clipped to a robust radius and averaged.
Variants disabling scoring, clipping, or robust centering are used in the
ablation.

This mechanism is not a proof of Byzantine resilience: non-IID legitimate
updates can be distant from the center, and adaptive attackers can imitate
benign directions.

## 5. Synthetic dataset

The generator creates eight documented features: packet rate, byte rate, flow
duration, protocol entropy, failed connections, unique destinations, DNS
ratio, and TCP ratio. Benign observations use device-profile distributions;
attack observations alter rates, entropy, connection failures, destinations,
and DNS ratio. Device shifts are controlled by a heterogeneity parameter.
Records are labelled synthetic. Each client receives a deterministic
train/validation/test assignment from its seed, and normalization statistics
are fitted only to training records.

These assumptions are useful for controlled experiments but are not a
substitute for public IoT traffic. The separate N-BaIoT pilot uses actual
115-feature records and is reported independently below.

## 6. Experimental setup

The corrected standard matrix uses ten clients, 160 samples per client, eight
rounds, two local epochs, five seeds (7, 17, 27, 37, 47), attack fractions
0/10/20/30%, sign-flip and noise attacks, and heterogeneity 0.0/0.7. The
corrected raw records are under `results/standard_10/raw/`.

The ablation matrix uses four ARS variants and five seeds. The adaptive matrix
compares static sign flip with grey-box adaptive evasion. The scalability
pilot uses 6/10/20 clients and 0/20% dropout. The resource pilot uses ten
clients, four rounds, and artificial per-client delays of 0/2/10 ms.
The corrected N-BaIoT comparison samples 250 rows per source CSV, uses nine
device clients, five rounds, one local epoch, and seeds 7, 17, 27, 37, and 47.
It includes clean and two-of-nine (22.22%) sign-flip conditions. The full
archive was not loaded into a federated run, and source files are split
row-wise, leaving capture-level leakage risk.

## 7. Baselines and metrics

FedAvg and FedAvgM are non-robust baselines. Coordinate median, trimmed mean,
and Krum are established robust aggregation baselines. Krum is configured
with \(f=3\) for ten clients, satisfying \(n>2f+2\), and selects one update
without claiming to identify malicious clients. Metrics include accuracy, precision,
recall, F1, macro-F1, FPR, FNR, communication scalar counts, aggregation
time, detection precision/recall, and benign rejection rate. Detection metrics
refer to client flags and are not intrusion-classification metrics.

## 8. Results

In the corrected synthetic matrix, averaging across attack types and
heterogeneity levels, final accuracy was approximately:

| Malicious fraction | FedAvg | FedAvgM | Median | Trimmed mean | ARS |
|---:|---:|---:|---:|---:|---:|
| 0% | 0.9975 | 0.9975 | 0.9971 | 0.9975 | 0.9971 |
| 10% | 0.9652 | 0.9652 | 0.9975 | 0.9979 | 0.9977 |
| 20% | 0.9490 | 0.9496 | 0.9977 | 0.9983 | 0.9979 |
| 30% | 0.4479 | 0.4487 | 0.9983 | 0.9515 | 0.9983 |

These values are from `results/standard_10/summary.csv` and are synthetic
only. They do not establish universal superiority; attack-specific values
and variability are in the source table.

A separate five-seed Krum pilot used 120 samples per client and sign-flip
attacks. Krum's mean accuracy was approximately 0.997 at both 20% and 30%
malicious fractions across the two heterogeneity settings. This pilot is
stored separately in `results/krum/summary.csv` and is not directly comparable
to the 160-sample standard matrix.

### N-BaIoT pilot and comparison

The UCI N-BaIoT archive passed CRC validation. 7-Zip tested all 16 RAR
members, yielding 80 attack CSVs across nine devices; all extracted files
matched the 115-column schema and had no profiled invalid numeric values.
The loader derives binary labels from benign versus attack source paths,
splits each source file before fitting training-only normalization, and uses
device directories as clients. The original comparison labelled one malicious
client as 20%; the audit found this was 1/9 because of floor rounding and
those historical outputs are not treated as an exact 20% experiment.

Final-round F1 means over five matched seeds were:

| Condition | FedAvg | FedAvgM | Median | Trimmed mean | Krum | ARS |
|---|---:|---:|---:|---:|---:|---:|
| Clean | 0.8074 | 0.8117 | 0.7763 | 0.8041 | 0.7800 | 0.7839 |
| 2/9 sign-flip | 0.7144 | 0.7136 | 0.9371 | 0.8201 | 0.8750 | 0.8156 |

These values are bounded pilot measurements from
`results/real_nbaiot_expanded/statistics.csv`, not full-dataset validation.
Coordinate median had the highest mean F1 in the tested sign-flip condition;
ARS was not superior. Exact paired sign-flip tests against ARS used five
matched seeds; the smallest p-value was 0.0625, so no significance claim is
made.

### Source-group holdout

To address capture-level correlation, a second protocol kept each complete
CSV source file in exactly one partition. The split used 61 training groups,
10 validation groups, and 18 test groups per seed, with both classes present
in every partition. Devices remained federated clients in all partitions, so
this is unseen-source-file evaluation within seen devices, not unseen-device
generalization.

The holdout final-round F1 means were:

| Condition | FedAvg | FedAvgM | Median | Trimmed mean | Krum | ARS |
|---|---:|---:|---:|---:|---:|---:|
| Source-group clean | 0.7819 | 0.7852 | 0.7374 | 0.7413 | 0.7959 | 0.8328 |
| Source-group 2/9 sign-flip | 0.7324 | 0.7314 | 0.8415 | 0.7982 | 0.9213 | 0.8863 |

The coordinate-median advantage from the row-wise evaluation did not persist.
ARS had the highest clean holdout mean, while Krum had the highest poisoned
holdout mean. These are descriptive five-seed results; the smallest exact
paired p-value against ARS was 0.0625, without multiplicity correction.

## 9. Statistical analysis

Means and sample standard deviations are computed over independent seeds, not
rounds. The project also produces normal-approximation 95% intervals clipped
to the metric range and exact paired sign-flip permutation p-values for
final-round F1 comparisons. Five synthetic seeds and five real-data seeds, no multiplicity correction,
and the small designs limit inferential strength. Results are generated by
`iot_fl.statistics`.

## 10. Ablation studies

The no-score variant eliminated benign rejection in the tested matrix but also
had zero malicious-client recall. Full ARS averaged about 10.6% benign
rejection and 50% detection recall across the ablation conditions. Mean
centering reduced rejection in some clean IID conditions but did not remove
the general trade-off. These are evidence that ARS components affect the
security/false-alarm balance, not evidence that every component is necessary.

## 11. Adaptive attack evaluation

The grey-box adaptive-evasion attacker aligns mostly with the benign reference
direction used by the server-side scoring process. ARS detection recall was
zero in the saved adaptive summary while benign rejection remained
approximately 7.5–15%. The tested adaptive attack therefore exposed an ARS
failure mode.

## 12. Scalability and resource analysis

The scalability pilot measured local-process wall-clock time from
approximately 0.0115 to 0.0260 seconds across the tested client/dropout
configurations. The dedicated resource pilot measured approximately 0.0301 s
at 0 ms artificial latency, 0.2117 s at 2 ms, and 0.8555 s at 10 ms. Peak
memory is traced Python allocation, not total resident memory. Communication
values count transmitted model scalars. Neither measurement is a physical IoT
benchmark.
The corrected N-BaIoT resource pilot took 353.62 seconds wall-clock and
102,998,315 peak traced Python bytes for clean loading plus six-method
training; the two-client sign-flip run took 312.31 seconds and 102,747,763
bytes. These are Python allocation proxies, not resident memory or physical
network measurements.

## 13. Discussion

The static attacks are sufficiently disruptive in this synthetic setup that
coordinate robust aggregators preserve classification performance better than
FedAvg/FedAvgM at high fractions. ARS has similar classification performance
in those conditions, but its explicit client flags are unreliable under
heterogeneity and adaptive evasion. The results support robust aggregation as
a useful experimental baseline, not an unconditional deployment
recommendation.

## 14. Limitations and threats to validity

The synthetic matrix uses generated data; the real-data comparison is bounded
to 250 rows per source file and is highly class-imbalanced. The model is a
small logistic classifier, the
heterogeneity mechanism is a deterministic profile shift rather than a full
Dirichlet or device trace model, and resource measurements are local software
proxies. Source-group holdout reduces row-wise capture leakage but does not
test unseen devices. Only five synthetic seeds and five real-data seeds were
used. No targeted
backdoor, physical hardware, secure aggregation, or formal privacy analysis
was completed. These limitations constrain generalization.

## 15. Reproducibility

```powershell
python -m pytest
python -m iot_fl.suite --config configs\standard_10_clients.json --output results\standard_10
python -m iot_fl.report results\standard_10
python -m iot_fl.statistics --input results\standard_10\all_rounds.csv --output results\tables\standard_10_statistics.csv
python -m iot_fl.suite --config configs\ablation.json --output results\ablation
python -m iot_fl.suite --config configs\adaptive.json --output results\adaptive
python -m iot_fl.resource --output results\resource
python -m iot_fl.experiment --config configs\nbaiot_corrected_pilot_clean.json --output results\real_nbaiot_audit\pilot_clean
python -m iot_fl.experiment --config configs\nbaiot_corrected_pilot_poisoning.json --output results\real_nbaiot_audit\pilot_poisoning
python -m iot_fl.statistics --input results\real_nbaiot_expanded\all_rounds.csv --output results\real_nbaiot_expanded\statistics.csv
python -m iot_fl.experiment --config configs\nbaiot_group_holdout_pilot_clean.json --output results\real_nbaiot_group_holdout\pilot_clean
python -m iot_fl.experiment --config configs\nbaiot_group_holdout_pilot_poisoning.json --output results\real_nbaiot_group_holdout\pilot_poisoning
python -m iot_fl.statistics --input results\real_nbaiot_group_holdout\all_rounds.csv --output results\real_nbaiot_group_holdout\statistics.csv
```

Completed outputs are resumable and remain in separate result directories.

## 16. Conclusion and future work

This project demonstrates a reproducible synthetic evaluation pipeline and
records both positive and negative findings. ARS cannot currently be claimed
as a reliable malicious-client detector or adaptive-attack defense. The
source-group result is a stronger leakage-aware validation, but it remains a
bounded within-device study. Future work should add unseen-device evaluation,
full-archive sampling, threshold tuning only on validation data, targeted
attacks, and controlled hardware measurements.

## References

1. Khraisat, A., Alazab, A., Alazab, M., Obeidat, A., Singh, S., & Jan, T.
   (2025). Federated learning for intrusion detection in IoT environments: a
   privacy-preserving strategy. *Discover Internet of Things*, 5, 72.
   https://doi.org/10.1007/s43926-025-00169-7
2. McMahan, B. et al. (2017). Communication-efficient learning of deep
   networks from decentralized data. *AISTATS*.
3. Blanchard, P., El Mhamdi, E. M., Guerraoui, R., & Stainer, J. (2017).
   Machine learning with adversaries: Byzantine tolerant gradient descent.
   *NeurIPS*.
4. Yin, D., Chen, Y., Kannan, R., & Bartlett, P. (2018). Byzantine-robust
   distributed learning: Towards optimal statistical rates. *ICML*, PMLR 80,
   5650–5659.
5. Xie, Y., Fang, M., & Gong, N. Z. (2024). FedREDefense: Defending against
   model poisoning attacks for federated learning using model update
   reconstruction error. *ICML*, PMLR 235, 54460–54474.
