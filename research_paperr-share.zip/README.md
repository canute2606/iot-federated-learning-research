# IoT-FL-Shield

This repository is a software-only, reproducible simulation for studying
poisoning-resilient federated intrusion detection under synthetic IoT traffic,
non-IID clients, dropout, and communication constraints. Synthetic results are
not evidence of real-device performance.

## Quick start

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -e .
python -m pytest
python -m iot_fl.experiment --config configs/smoke.json --output results/smoke
```

The experiment writes `metrics.csv`, `client_events.csv`, `config.json`, and
`summary.json`. `python -m iot_fl.plot results/smoke` creates plots from saved
outputs; it never uses hard-coded metrics. `python -m iot_fl.dashboard
results/smoke` creates a static HTML dashboard from `metrics.csv`.

The default defense, **Adaptive Robust Score (ARS)**, is an explicitly scoped
project contribution rather than a claim of publication novelty. It combines
coordinate-wise robust clipping with a temporally smoothed, norm-and-cosine
score. It is compared with FedAvg, FedAvgM, coordinate median, and trimmed
mean. The literature review explains its relationship to established methods.

For the corrected five-seed synthetic matrix (10 clients so 10/20/30% map to
1/2/3 clients), run:

```powershell
python -m iot_fl.suite --config configs\standard_10_clients.json --output results\standard_10
python -m iot_fl.report results\standard_10
```

Additional completed analyses:

```powershell
python -m iot_fl.statistics --input results\standard_10\all_rounds.csv --output results\tables\standard_10_statistics.csv
python -m iot_fl.suite --config configs\ablation.json --output results\ablation
python -m iot_fl.suite --config configs\adaptive.json --output results\adaptive
python -m iot_fl.resource --output results\resource
python -m iot_fl.suite --config configs\krum.json --output results\krum
python -m iot_fl.statistics --input results\krum\all_rounds.csv --output results\tables\krum_statistics.csv
python -m iot_fl.experiment --config configs\nbaiot_corrected_pilot_clean.json --output results\real_nbaiot_audit\pilot_clean
python -m iot_fl.experiment --config configs\nbaiot_corrected_pilot_poisoning.json --output results\real_nbaiot_audit\pilot_poisoning
python -m iot_fl.statistics --input results\real_nbaiot_expanded\all_rounds.csv --output results\real_nbaiot_expanded\statistics.csv
```

The current manuscript is [PAPER_DRAFT.md](PAPER_DRAFT.md). It remains a
draft because the real IoT evaluation is a bounded row-wise pilot with
capture-level leakage risk and the resource pilot uses artificial latency and
traced Python allocations.

The N-BaIoT archive is now available under `data\nbaiot`. Archive validation
completed for nine benign CSV files and 80 extracted attack CSVs with 115
consistent columns. The corrected expanded comparison is kept separately
under `results\real_nbaiot_expanded\`; the historical pilot is under
`results\real_nbaiot\`. Source-group holdout results are under
`results\real_nbaiot_group_holdout\`; they keep complete CSV files disjoint
between train, validation, and test, but still evaluate within seen devices.
Neither protocol supports a universal superiority claim.
