import pandas as pd
import pytest
from iot_fl.real_data import check_integrity, load_csv
from iot_fl.nbaiot import assign_source_groups

def test_real_loader_fits_and_checks(tmp_path):
    path = tmp_path / "traffic.csv"
    pd.DataFrame({"label": ["benign", "attack", "benign", "attack"],
                  "packet_rate": [1, 10, 2, 12],
                  "device": [0, 0, 1, 1]}).to_csv(path, index=False)
    data = load_csv(path, "label", "device", seed=3, test_fraction=.25)
    assert check_integrity(data)["classes"] == 2
    assert data.feature_names == ("packet_rate",)

def test_real_loader_rejects_missing_file(tmp_path):
    with pytest.raises(FileNotFoundError):
        load_csv(tmp_path / "missing.csv", "label")

def test_source_groups_are_disjoint(tmp_path):
    benign = tmp_path / "benign"
    attack = tmp_path / "attack"
    sources = [(benign / f"device_{i}" / "benign_traffic.csv", 0, benign)
               for i in range(3)]
    sources.extend(
        (attack / "device_0" / f"attack_{i}.csv", 1, attack)
        for i in range(3)
    )
    assignments = assign_source_groups(sources, seed=7,
                                       test_fraction=.2,
                                       validation_fraction=.1)
    groups = [set(group for group, split in assignments.items() if split == name)
              for name in ("train", "val", "test")]
    assert all(groups[i].isdisjoint(groups[j])
               for i in range(3) for j in range(i + 1, 3))
