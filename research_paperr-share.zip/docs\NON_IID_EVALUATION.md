# Non-IID evaluation

The standard suite compares `heterogeneity=0.0` and `heterogeneity=0.7`.
The generator applies deterministic device-profile feature shifts; it does not
claim to be a Dirichlet partition. Both settings use matched seeds and the same
model/training budget. Results remain pending until the suite command is run.

