# Dataset card

## Current status

The official UCI N-BaIoT archive is present under `data/nbaiot/` and passed
ZIP CRC validation. Nine benign CSVs and 80 attack CSVs were extracted after
all 16 RAR members passed 7-Zip testing. The files contain 115 consistent
numeric feature columns. Chunked profiling observed 555,932 benign rows and
6,506,674 attack rows with no missing or invalid/non-finite numeric values.
The full archive is preserved; the federated experiments use a bounded sample.

## Source and license

N-BaIoT contains traffic from nine commercial IoT devices infected with Mirai
and BASHLITE/Gafgyt, with benign records and attack subtypes. The UCI record
reports the dataset source and CC BY 4.0 license:
https://archive.ics.uci.edu/dataset/442/detection+of+iot+botnet+attacks+n+baiot

## Real-data protocol

`iot_fl.nbaiot.load_nbaiot` maps benign files to class 0 and attack files to
class 1, uses device directories as clients, samples a configurable number of
rows per source CSV, splits each source before preprocessing, and fits
normalization statistics on training rows only. The corrected expanded comparison uses 250 rows per source file, five seeds,
and five rounds, with two explicit malicious clients out of nine. It is a
pilot-scale evaluation, not a claim of full-dataset performance.

The source-group holdout uses complete CSV paths as atomic groups. It assigns
61 groups to training, 10 to validation, and 18 to test per seed, with both
classes in every partition. Devices remain represented in all federated
client assignments, so this tests unseen source files within seen devices,
not unseen-device generalization.

## Synthetic data disclosure

The synthetic generator creates eight documented features with configurable
device-profile shifts and attack prevalence. These records are labelled
synthetic and must not be described as N-BaIoT or real-world validation.
