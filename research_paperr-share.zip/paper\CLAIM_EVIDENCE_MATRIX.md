# Claim/evidence matrix

| Claim | Evidence | Status |
|---|---|---|
| Robust aggregation can preserve synthetic detection performance under the tested static attacks | `results/standard_10/summary.csv` | Supported only for tested synthetic configurations |
| ARS identifies malicious clients reliably under heterogeneous traffic | `results/standard_10/summary.csv`, `results/ablation/summary.csv` | Not supported; benign rejection is non-zero |
| ARS resists adaptive attacks | `results/adaptive/summary.csv` | Not supported; adaptive-evasion recall was zero |
| The method is suitable for physical IoT devices | None | Not evaluated |
| The method is novel | Literature review only | Not claimed |
| The results generalize to real IoT traffic | None | Not evaluated |
| Client count and dropout affect measured runtime/communication | `results/scalability/scalability.csv` | Supported as a local simulation pilot only |
| Corrected matrix has five independent seeds per condition | `results/standard_10/summary.json`, `docs/RESULTS_VALIDATION.md` | Verified: seeds 7, 17, 27, 37, 47 |
| At 20% malicious fraction, mean accuracy is FedAvg 0.9490 and ARS 0.9979 | `results/standard_10/summary.csv` | Verified synthetic aggregate across attack/heterogeneity conditions |
| At 30% malicious fraction, mean accuracy is median/ARS 0.9983 and FedAvg 0.4479 | `results/standard_10/summary.csv` | Verified synthetic aggregate; not generalizable |
| ARS benign rejection averages about 10.6% in the ablation matrix | `results/ablation/summary.csv` | Verified descriptive five-seed aggregate |
| ARS detection recall is zero in adaptive-evasion evaluation | `results/adaptive/summary.csv` | Verified for the tested grey-box attack; not a universal claim |
| Artificial latency increases local wall-clock time from about 0.0301 s to 0.8555 s | `results/resource/resource.csv`, `docs/RESOURCE_EVALUATION.md` | Verified one-seed software pilot; artificial delay, not network hardware |
| Real IoT validation was completed | None; `docs/REAL_DATASET_RESULTS.md` | Explicitly false/pending; no local dataset was available |
| N-BaIoT archive contains nine benign CSVs and 80 extracted attack CSVs with 115 consistent columns | `data/nbaiot/manifest.json` | Verified extraction/profile fact; not a model result |
| Historical N-BaIoT comparison completed | `results/real_nbaiot/all_metrics.csv` | Three seeds and 100 rows per source file; condition labelled 20% but actually poisoned one of nine clients |
| Corrected expanded N-BaIoT comparison completed | `results/real_nbaiot_expanded/all_rounds.csv` | Five matched seeds, 250 rows per source file, five rounds, two of nine malicious clients |
| ARS is superior on N-BaIoT | `results/real_nbaiot_expanded/statistics.csv` | Unsupported; coordinate median had the highest mean F1 under corrected sign-flip |
| N-BaIoT paired comparisons are statistically significant | `results/real_nbaiot_expanded/paired_sign_flip.csv` | Unsupported; five pairs, smallest exact p-value 0.0625, no multiplicity correction |
| N-BaIoT source-level generalization is established | `docs/REAL_DATA_AUDIT.md` | Unsupported; current expanded runs use row-wise within-file splits and retain capture-level leakage risk |
| Source-group holdout keeps source files disjoint | `results/real_nbaiot_group_holdout/*/dataset_summary.json`, `tests/test_real_data.py` | Supported; 61 train, 10 validation, and 18 test groups, with both classes in every partition |
| Coordinate median remains best under source-group holdout | `results/real_nbaiot_group_holdout/statistics.csv` | Unsupported; ARS was best clean and Krum was best under 2/9 sign-flip |
| ARS is universally best under source-group holdout | `results/real_nbaiot_group_holdout/statistics.csv` | Unsupported; Krum had higher poisoned mean F1 than ARS |
| Source-group holdout is unseen-device generalization | `docs/REAL_DATA_PARTITIONING.md` | Unsupported; all nine devices remain represented as clients |
| Krum is an established baseline in this implementation | `results/krum/summary.csv`, `iot_fl/aggregation.py`, `configs/krum.json` | Verified synthetic five-seed pilot; `f=3`, ten clients, `n > 2f + 2`; Krum selects rather than identifies clients |
| Krum mean accuracy is approximately 0.997 at 20% and 30% in its pilot | `results/krum/summary.csv` | Verified separate 120-sample synthetic pilot; not directly comparable to the standard 160-sample matrix |

All numerical claims must be regenerated from the referenced CSV files if
configurations or code change.
