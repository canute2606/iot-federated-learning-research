"""Generate a static dashboard from persisted experiment outputs."""
import html
import sys
from pathlib import Path
import pandas as pd

def main():
    root = Path(sys.argv[1])
    metrics = pd.read_csv(root / "metrics.csv")
    latest = metrics.sort_values("round").groupby("method").tail(1)
    rows = "".join(
        f"<tr><td>{html.escape(str(r.method))}</td><td>{r.accuracy:.4f}</td>"
        f"<td>{r.f1:.4f}</td><td>{int(r.flagged_clients)}</td>"
        f"<td>{int(r.communication_values)}</td></tr>"
        for r in latest.itertuples()
    )
    (root / "dashboard.html").write_text(
        "<!doctype html><meta charset='utf-8'><title>IoT-FL results</title>"
        "<h1>Saved synthetic experiment outputs</h1>"
        "<p>Values below are read from metrics.csv; no example values are embedded.</p>"
        "<table border='1'><tr><th>Method</th><th>Accuracy</th><th>F1</th>"
        "<th>Flagged clients</th><th>Communication values</th></tr>" + rows + "</table>",
        encoding="utf-8",
    )

if __name__ == "__main__": main()
