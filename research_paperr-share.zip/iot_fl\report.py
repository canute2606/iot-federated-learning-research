"""Create tables and figures from completed suite records only."""
import argparse
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

def create_report(root):
    root = Path(root)
    summary = pd.read_csv(root / "summary.csv")
    tables = root / "tables"; figures = root / "figures"
    tables.mkdir(exist_ok=True); figures.mkdir(exist_ok=True)
    summary.to_csv(tables / "baseline_comparison.csv", index=False)
    for attack in sorted(summary.attack.unique()):
        subset = summary[summary.attack == attack]
        pivot = subset[subset.heterogeneity == .7].pivot_table(
            index="attack_fraction", columns="method", values="accuracy_mean")
        ax = pivot.plot(marker="o", title=f"Accuracy vs malicious fraction ({attack})")
        ax.set_ylabel("Accuracy (mean over seeds)"); ax.set_xlabel("Malicious fraction")
        ax.figure.tight_layout()
        ax.figure.savefig(figures / f"accuracy_vs_attack_{attack}.png"); plt.close(ax.figure)
    pivot = summary[summary.attack_fraction == .2].pivot_table(
        index="heterogeneity", columns="method", values="f1_mean")
    ax = pivot.plot(marker="o", title="F1 vs synthetic heterogeneity at 20% attack")
    ax.set_ylabel("F1 (mean over seeds)"); ax.set_xlabel("Heterogeneity")
    ax.figure.tight_layout(); ax.figure.savefig(figures / "f1_vs_heterogeneity.png"); plt.close(ax.figure)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root")
    args = parser.parse_args()
    create_report(args.root)

if __name__ == "__main__":
    main()
