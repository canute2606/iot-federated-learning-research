# Baseline comparison

The matched methods are FedAvg, FedAvgM, coordinate-wise median, trimmed mean,
and ARS. The first four are baselines or established robust aggregators; ARS is
the project method under evaluation and is not presumed superior. The
machine-readable comparison will be generated at
`results/standard/summary.csv` after the standard suite completes.

