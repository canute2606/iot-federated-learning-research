# N-BaIoT real-data experiment audit

## Scope

This audit covers the bounded comparison in
`results/real_nbaiot/clean_{7,17,27}` and
`results/real_nbaiot/signflip_{7,17,27}`. No expanded experiment was started
while this audit was performed, and the existing outputs were not overwritten.

## Confirmed implementation behavior

- The loader walks sorted benign and attack CSV paths. For each source file it
  reads the full file, samples at most `max_rows_per_file=100` rows without
  replacement using a seed-controlled NumPy generator, then shuffles those
  sampled rows for splitting. Repeated calls with the same seed and file tree
  are deterministic by construction.
- Binary labels are derived from the source root: benign files are class 0 and
  attack files are class 1. Device directory names define nine client IDs.
- The bounded sample has 8,900 rows: 900 benign and 8,000 attack. Client totals
  are 600 or 1,100 rows. Every client has 100 benign rows; six clients have
  1,000 attack rows and two clients have 500 attack rows. The global
  train/validation/test class counts are respectively 630/5,600,
  90/800, and 180/1,600.
- Splits are created independently inside every source CSV, with 70% train,
  10% validation, and 20% test. Scaling statistics are fitted on all rows
  labelled train and then applied to validation and test.
- The held-out metrics use `data.split == "test"` and the positive class is
  `y == 1` (attack) for every method. The confusion-matrix counts in the CSVs
  reproduce the reported F1 values.
- Each method receives the same loaded dataset and client partitions. With
  dropout disabled, each method receives the same client IDs and local
  training inputs. The per-method RNG is reset to the same seed. Krum and ARS
  intentionally transform the common update array differently.
- `sign_flip` returns `-3 * update`. In the prior nine-client runs,
  `int(9 * 0.2)` equals one, so client 0 was malicious in every round.
  The actual malicious fraction was 1/9 = 11.1%, not 20%. The saved
  `malicious_clients=1` fields correctly reflect execution but the condition
  label overstates the intended fraction.
- Each saved run has 18 rows (six methods and three rounds), with six final
  rows. The prior aggregate tables therefore agree with the saved run rows,
  subject to the incorrect 20% condition label.

## Confirmed methodological risks

1. **Malicious-client fraction bug:** client count is computed with floor
   rounding from a fraction. Exact 20% is impossible for nine clients; the
   prior condition used one client rather than a documented target of two.
2. **Capture/source leakage risk:** rows from the same source CSV are randomly
   divided across train, validation, and test. This prevents no source-level
   correlation leakage; it only prevents a sampled row from appearing twice.
   The source file/device and attack subtype are therefore represented in both
   training and test data. The current documentation claim that source streams
   do not cross splits is too strong.
3. **Sampling memory risk:** `load_nbaiot` reads each complete CSV before
   selecting 100 rows. The federated model sees a bounded sample, but the
   loader is not bounded-memory with respect to the raw files.
4. **Validation is not used for model selection:** validation rows are created
   but the runner evaluates test rows after every round without threshold
   tuning or early stopping. This is acceptable for a fixed-threshold pilot but
   should not be presented as validation-based model selection.
5. **Client composition is strongly imbalanced:** every client has the same
   sampled benign count but different attack-file counts. Client 0 is not
   special by class count, but it is always the poisoned client under the old
   ID rule.

## Unexpected F1 pattern

The clean and sign-flip runs use the same seed, sampling rule, split rule,
client IDs, test set, rounds, and local training settings. The higher poisoned
F1 is therefore not caused by a changed held-out test set. It is visible in
the confusion matrices:

- FedAvg seed 7: clean `(TN,FP,FN,TP)=(179,1,527,1073)`;
  sign-flip `(167,13,319,1281)`.
- Trimmed mean seed 7: clean F1 `0.7976`; sign-flip F1 `0.9017`.
- Krum is unchanged because it selects the same effective update trajectory in
  both saved conditions.

The evidence supports a short-run decision-boundary effect: the single
sign-flipped client changes the aggregate direction and increases attack
recall substantially, while causing only a small false-positive increase.
The result is not a security benefit and should not be generalized. It also
cannot be interpreted as a 20% poisoning result because only one client was
poisoned.

## Proposed changes before expanded evaluation

1. Add an explicit `malicious_clients` configuration field and reject
   ambiguous fraction rounding for real-data runs. Use two malicious clients
   for a documented 2/9 (22.2%) condition, or report the exact realized
   fraction in every result.
2. Add a streaming/bounded-memory sampling path and preserve source-file IDs.
3. Add a source-group holdout sensitivity run, keeping whole source files out
   of test where class/client coverage permits. Report it separately from the
   existing row-wise pilot.
4. Add client class-distribution and realized malicious-client metadata to
   saved summaries.
5. Preserve the original outputs and run all corrected and expanded results in
   new directories.

No claim of ARS superiority, poisoning resilience, or statistical significance
is supported by the audited comparison.
