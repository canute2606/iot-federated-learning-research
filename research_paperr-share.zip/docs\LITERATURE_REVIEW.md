# Literature review and gap analysis

## Verification status

The supplied PDF was inspected as the primary source. Its metadata identifies
the DOI `10.1007/s43926-025-00169-7`. Bibliographic metadata was cross-checked
against the publisher-indexed record: Khraisat, A., Alazab, A., Alazab, M.,
Obeidat, A., Singh, S., & Jan, T. (2025), “Federated learning for intrusion
detection in IoT environments: a privacy-preserving strategy,” *Discover
Internet of Things*, 5, Article 72. The DOI is the canonical identifier.

The implementation below does not claim that PEIoT-DS implements poisoning
resistance. Its role here is the privacy-preserving IoT-FL baseline described
in the supplied paper. Exact page-level claims about future work should be
checked against the final publisher text before publication.

| Method | Contribution / threat model | Advantage | Limitation relevant here |
|---|---|---|---|
| PEIoT-DS (Khraisat et al., 2025) | Federated IoT intrusion detection with local data retention | Privacy-oriented IoT architecture | This project treats poisoning resilience, heterogeneous clients, and resource overhead as separate hypotheses to test; no equivalence or superiority is assumed |
| FedAvg (McMahan et al., 2017) | Weighted averaging of client model updates | Simple, communication efficient | Vulnerable to arbitrary malicious updates |
| Krum (Blanchard et al., 2017) | Distance-based Byzantine-resilient gradient selection | Explicit Byzantine threat model | Requires assumptions on the number of Byzantine clients and can reject valid non-IID updates |
| Coordinate median / trimmed mean (Yin et al., 2018) | Coordinate-wise robust statistics | Low implementation complexity | Coordinate independence can discard useful correlated updates |
| FedREDefense (Xie et al., 2024) | Reconstruction-error filtering of model updates under non-IID data | Does not require benign clients to dominate | More computation and a different local-knowledge/reconstruction pipeline than this lightweight simulator |

## Project contribution boundary

ARS (Adaptive Robust Score) is implemented as a transparent engineering
combination of robust centering, norm clipping, and temporal similarity. It is
**not** asserted to be novel against the full literature. The defensible
contribution of this repository is a reproducible comparison protocol for
synthetic IoT traffic, poisoning, non-IID severity, client dropout, and
resource/communication measurements. A publication claim requires a systematic
literature search and experiments beyond this smoke configuration.

Krum is now implemented as an additional baseline. The pilot sets `f=3` for
ten clients, satisfying the implementation's `n > 2f + 2` guard. Krum selects
one update and does not identify malicious clients, so its client-detection
precision/recall fields are not interpreted as Krum detection performance.

## References

1. Khraisat, A., Alazab, A., Alazab, M., Obeidat, A., Singh, S., & Jan, T.
   (2025). *Federated learning for intrusion detection in IoT environments: a
   privacy-preserving strategy*. Discover Internet of Things, 5, 72.
   https://doi.org/10.1007/s43926-025-00169-7
2. McMahan, B. et al. (2017). *Communication-efficient learning of deep
   networks from decentralized data*. AISTATS.
3. Blanchard, P., El Mhamdi, E. M., Guerraoui, R., & Stainer, J. (2017).
   *Machine learning with adversaries: Byzantine tolerant gradient descent*.
   NeurIPS.
4. Yin, D., Chen, Y., Kannan, R., & Bartlett, P. (2018).
   *Byzantine-robust distributed learning: Towards optimal statistical rates*.
   ICML, PMLR 80, 5650–5659.
5. Xie, Y., Fang, M., & Gong, N. Z. (2024). *FedREDefense: Defending against
   model poisoning attacks for federated learning using model update
   reconstruction error*. ICML, PMLR 235, 54460–54474.
6. Meidan, Y., Bohadana, M., Mathov, Y., Mirsky, Y., Breitenbacher, D.,
   Aharonov, M., & Shabtai, A. (2018). *N-BaIoT: Network-based detection of
   IoT botnet attacks using deep autoencoders*. IEEE Pervasive Computing,
   17(3), 12–22. https://doi.org/10.1109/MPRV.2018.03367731
