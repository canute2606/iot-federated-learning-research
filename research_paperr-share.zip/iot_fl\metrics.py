import numpy as np

def classification(y, pred):
    tp = int(((y == 1) & (pred == 1)).sum()); tn = int(((y == 0) & (pred == 0)).sum())
    fp = int(((y == 0) & (pred == 1)).sum()); fn = int(((y == 1) & (pred == 0)).sum())
    precision = tp / max(1, tp + fp); recall = tp / max(1, tp + fn)
    return {"accuracy": (tp + tn) / max(1, len(y)), "precision": precision,
            "recall": recall, "f1": 2 * precision * recall / max(1e-12, precision + recall),
            "benign_precision": tn / max(1, tn + fn),
            "benign_recall": tn / max(1, tn + fp),
            "attack_precision": precision, "attack_recall": recall,
            "macro_f1": ((tn / max(1, tn + fp) + tp / max(1, tp + fn)) / 2),
            "fpr": fp / max(1, fp + tn), "fnr": fn / max(1, fn + tp),
            "tp": tp, "tn": tn, "fp": fp, "fn": fn}
