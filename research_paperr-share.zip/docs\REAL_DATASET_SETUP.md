# Real dataset setup

The N-BaIoT archive is present under `data/nbaiot/` and passed ZIP CRC
validation. It contains nine benign CSV files and sixteen attack RAR files.
The current validation processed only the benign CSVs; no
benign-versus-attack experiment has run because no RAR extraction backend is
available. N-BaIoT is the preferred candidate:
the UCI Machine Learning Repository record identifies 7,062,606 instances
from nine commercial IoT devices, benign plus ten attack classes, and a
1.7 GB ZIP download. It is licensed CC BY 4.0. Source:
https://archive.ics.uci.edu/dataset/442/detection+of+iot+botnet+attacks+n+baiot
and the associated paper is Meidan et al. (2018),
https://doi.org/10.1109/MPRV.2018.03367731. A future N-BaIoT integration must
verify source, license, schema, class mapping, missing values, and train-only
preprocessing before producing any real-dataset claim.

After obtaining an authorized CSV:

```powershell
python -c "from iot_fl.real_data import load_csv,check_integrity; d=load_csv('PATH.csv', label_column='LABEL', client_column=None, seed=7); print(check_integrity(d))"
```

The loader rejects missing files and non-numeric feature sets, maps categorical
labels to integer classes reproducibly, imputes numeric missing values, and
fits normalization statistics only on the generated training partition.

The archive validation manifest is `data/nbaiot/manifest.json`. It reports
555,932 benign rows across nine files, each with 115 consistent numeric
feature columns. Exact duplicate detection was limited to within-chunk
checks; a full global duplicate scan was not performed.
