# Resource evaluation

The dedicated pilot is stored in `results/resource/resource.csv` and uses
10 clients, 100 samples per client, four rounds, FedAvg and ARS, 20% sign-flip
poisoning, and artificial per-client delays of 0, 2, and 10 ms.

Measured local-process wall-clock times were approximately:

| Artificial latency | Wall-clock |
|---:|---:|
| 0 ms | 0.0301 s |
| 2 ms | 0.2117 s |
| 10 ms | 0.8555 s |

Aggregation time is measured around the server aggregation call; local
training time is recorded separately. Peak memory is measured with Python `tracemalloc`, so it covers traced Python
allocations during the pilot and not total operating-system resident memory.
Communication values are model-scalar counts, not packet or radio measurements.
Artificial latency is a controlled sleep and is not a physical network
benchmark. The pilot used one seed and is descriptive rather than inferential.
