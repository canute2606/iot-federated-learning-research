"""Federated aggregation algorithms and the proposed ARS defense."""
from dataclasses import dataclass
import numpy as np

@dataclass
class AggregationResult:
    update: np.ndarray
    weights: np.ndarray
    flagged: np.ndarray

def fedavg(updates, sizes):
    w = np.asarray(sizes, dtype=float); w /= w.sum()
    return AggregationResult(np.average(updates, axis=0, weights=w), w, np.zeros(len(w), bool))

def coordinate_median(updates):
    return AggregationResult(np.median(updates, axis=0), np.ones(len(updates)) / len(updates), np.zeros(len(updates), bool))

def trimmed_mean(updates, trim=.2):
    n = len(updates); k = min(int(n * trim), max(0, (n - 1) // 2))
    ordered = np.sort(updates, axis=0)
    return AggregationResult(ordered[k:n-k].mean(0), np.ones(n) / n, np.zeros(n, bool))

def krum(updates, byzantine_clients=1):
    """Select one update using Krum's nearest-neighbour score.

    Krum assumes n > 2f + 2 and at most f Byzantine clients. It selects an
    update but does not identify malicious clients.
    """
    n = len(updates)
    f = int(byzantine_clients)
    if f < 0 or n <= 2 * f + 2:
        raise ValueError("Krum requires n > 2*f + 2")
    distances = np.sum((updates[:, None, :] - updates[None, :, :]) ** 2, axis=2)
    neighbour_count = n - f - 2
    scores = np.empty(n)
    for i in range(n):
        scores[i] = np.sort(np.delete(distances[i], i))[:neighbour_count].sum()
    selected = int(np.argmin(scores))
    weights = np.zeros(n)
    weights[selected] = 1.0
    return AggregationResult(updates[selected].copy(), weights, np.zeros(n, bool))

def ars(updates, previous=None, trim=.2, threshold=3.0,
        use_score=True, use_clip=True, use_robust=True):
    """Adaptive Robust Score: robust center + bounded temporal similarity score."""
    center = np.median(updates, axis=0) if use_robust else np.mean(updates, axis=0)
    distances = np.linalg.norm(updates - center, axis=1)
    scale = np.median(np.abs(distances - np.median(distances))) + 1e-8
    score = (distances - np.median(distances)) / scale if use_score else np.zeros(len(updates))
    if use_score and previous is not None:
        denom = np.linalg.norm(updates, axis=1) * (np.linalg.norm(previous) + 1e-8)
        cosine = (updates @ previous) / (denom + 1e-8)
        score += np.maximum(0, .5 - cosine)
    flagged = score > threshold
    keep = ~flagged
    if keep.sum() < max(2, len(updates) // 2):
        keep = np.argsort(score)[:max(2, len(updates) // 2)]
        flagged = ~np.isin(np.arange(len(updates)), keep)
    clipped = updates.copy()
    radius = np.quantile(distances[keep], .8) if keep.any() else np.max(distances)
    for i in range(len(updates)):
        if use_clip and distances[i] > radius:
            clipped[i] = center + (updates[i] - center) * radius / (distances[i] + 1e-8)
    result = fedavg(clipped[keep], np.ones(keep.sum()))
    weights = np.zeros(len(updates)); weights[keep] = result.weights
    return AggregationResult(result.update, weights, flagged)
