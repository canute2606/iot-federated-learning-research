import numpy as np
from iot_fl.data import make_dataset
from iot_fl.aggregation import ars, krum, trimmed_mean
from iot_fl.experiment import _malicious_count
from iot_fl.metrics import classification

def test_generation_is_reproducible_and_split_safe():
    a = make_dataset(clients=3, samples_per_client=30, seed=4)
    b = make_dataset(clients=3, samples_per_client=30, seed=4)
    assert np.array_equal(a.x, b.x) and np.array_equal(a.split, b.split)
    assert set(a.client[a.split == "train"]) == set(a.client[a.split == "test"])
    assert len(a.x[a.split == "train"]) + len(a.x[a.split == "test"]) + len(a.x[a.split == "val"]) == 90

def test_trimmed_mean_limits_coordinate_outlier():
    x = np.zeros((5, 3)); x[-1] = 100
    assert np.allclose(trimmed_mean(x, .2).update, 0)

def test_ars_flags_reversed_update():
    x = np.vstack([np.ones(4) * .1 for _ in range(4)] + [np.ones(4) * -20])
    result = ars(x)
    assert result.flagged[-1]

def test_krum_selects_consistent_update_without_client_detection():
    x = np.vstack([np.zeros(4), np.ones(4) * .1, np.ones(4) * .2,
                   np.ones(4) * .15, np.ones(4) * 50])
    result = krum(x, byzantine_clients=1)
    assert np.linalg.norm(result.update) < 1
    assert not result.flagged.any()

def test_metrics_shape():
    result = classification(np.array([0, 1, 1]), np.array([0, 1, 0]))
    assert result["tp"] == 1 and result["fn"] == 1

def test_explicit_malicious_client_count_overrides_fraction_rounding():
    assert _malicious_count({"clients": 9, "attack_fraction": .2,
                             "malicious_clients": 2}) == 2
