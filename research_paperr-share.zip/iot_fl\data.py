"""Leakage-safe synthetic IoT traffic generation."""
from dataclasses import dataclass
import numpy as np

FEATURE_NAMES = (
    "packet_rate", "byte_rate", "flow_duration", "protocol_entropy",
    "failed_connections", "unique_destinations", "dns_ratio", "tcp_ratio",
)

@dataclass
class Dataset:
    x: np.ndarray
    y: np.ndarray
    client: np.ndarray
    split: np.ndarray

def _profile(rng, n, attack, shift):
    normal = rng.normal(0, 1, (n, 8))
    normal[:, 0] = rng.lognormal(2.0 + shift, .45, n)
    normal[:, 1] = rng.lognormal(4.0 + shift, .6, n)
    normal[:, 2] = rng.lognormal(1.3, .5, n)
    normal[:, 3] = rng.beta(3, 8, n)
    normal[:, 4] = rng.poisson(1.0 + max(shift, 0), n)
    normal[:, 5] = rng.poisson(3.0 + max(shift, 0), n)
    normal[:, 6] = rng.beta(2, 8, n)
    normal[:, 7] = rng.beta(7, 2, n)
    if not attack:
        return normal, np.zeros(n, dtype=np.int64)
    attack_x = normal.copy()
    attack_x[:, 0] *= 3.0
    attack_x[:, 1] *= 2.5
    attack_x[:, 3] = rng.beta(8, 2, n)
    attack_x[:, 4] += rng.poisson(5, n)
    attack_x[:, 5] += rng.poisson(8, n)
    attack_x[:, 6] = rng.beta(7, 2, n)
    return attack_x, np.ones(n, dtype=np.int64)

def make_dataset(clients=8, samples_per_client=300, attack_prevalence=.25,
                 heterogeneity=.7, seed=0, test_fraction=.2):
    """Create synthetic records; split is assigned before any client training."""
    rng = np.random.default_rng(seed)
    xs, ys, cs, ss = [], [], [], []
    for client in range(clients):
        shift = heterogeneity * ((client % 4) - 1.5) / 2
        n_attack = rng.binomial(samples_per_client, attack_prevalence)
        x0, y0 = _profile(rng, samples_per_client - n_attack, False, shift)
        x1, y1 = _profile(rng, n_attack, True, shift)
        x, y = np.concatenate([x0, x1]), np.concatenate([y0, y1])
        order = rng.permutation(len(y))
        test_n = max(1, int(len(y) * test_fraction))
        split = np.full(len(y), "train", dtype="<U5")
        split[order[:test_n]] = "test"
        val_n = max(1, int(len(y) * .1))
        split[order[test_n:test_n + val_n]] = "val"
        xs.append(x); ys.append(y); cs.append(np.full(len(y), client)); ss.append(split)
    x = np.concatenate(xs); y = np.concatenate(ys); client = np.concatenate(cs); split = np.concatenate(ss)
    mean, std = x[split == "train"].mean(0), x[split == "train"].std(0) + 1e-8
    return Dataset((x - mean) / std, y, client, split)

def client_partitions(data, split="train"):
    return {int(c): np.flatnonzero((data.client == c) & (data.split == split))
            for c in np.unique(data.client)}

