# N-BaIoT partitioning protocol

## Executed device-aware setting

The extracted directory structure defines nine device clients. The current
loader samples a configured number of rows from every source CSV, derives
binary labels from benign versus attack roots, and assigns each row to the
device client. Splits are seeded and created independently within each source
CSV before training-only normalization. Client class counts and split counts
are saved in each run's `dataset_summary.json`.

## Important limitation

The current evaluation uses row-wise splits within source CSVs. Rows from the
same capture/source file can therefore occur in train, validation, and test.
This is a capture-level correlation/leakage risk. The expanded results must
not be described as source-level generalization or deployment validation.

## Controlled non-IID setting

No separate reassignment of training rows across synthetic clients was used
for the N-BaIoT results. Device identity is retained as the client boundary,
which is the primary real-data setting. The source-group holdout below assigns complete source files to
train/validation/test where class and device coverage permit, and reports the
resulting client/class combinations.

The synthetic experiments use deterministic device-profile shifts and must not
be described as this real-data partitioning protocol.

## Source-group holdout setting

The observed tree contains one benign file per device and attack files grouped
by device, botnet family (`gafgyt_attacks` or `mirai_attacks`), and subtype
filename. Each complete CSV path is treated as one atomic source group. The
loader assigns groups with a seeded procedure:

- benign groups are shuffled globally and assigned to train, validation, and
  test;
- attack groups are shuffled separately within each device, preserving attack
  coverage for every device client;
- no rows from a source group cross partitions;
- normalization statistics are fitted only on training-group rows.

The five-seed holdout runs used 61 train groups, 10 validation groups, and 18
test groups. Each partition contained both classes. With 250 sampled rows per
source file, the test partition contained 500 benign and 4,000 attack rows.
This is unseen-source-file evaluation within seen devices, not unseen-device
generalization: every device remains represented among the federated clients.
