# Architecture

```text
config.json
    |
synthetic generator --> leakage-safe client partitions
    |                                  |
    +--> local NumPy logistic training-+
                                       v
                         attack simulator (compromised clients)
                                       v
          FedAvg | FedAvgM | median | trimmed mean | ARS
                                       v
                          held-out test + resource metrics
                                       v
                   CSV results --> plots / dashboard consumers
```

Modules are deliberately small: `data.py` owns generation and splits,
`model.py` owns local optimization, `aggregation.py` owns server rules,
`attacks.py` owns adversarial updates, and `experiment.py` is orchestration.

